import datetime, hashlib, json, mmap, os, re, stat
from pathlib import Path

CACHE = Path('/root/.cache/go-build')
CAP = 8 * 1024**3
LIMIT = 1024
HEADER = re.compile(rb'^go object linux amd64 go1\.26\.6(?: |\n)[^\n]*', re.M)
SOURCES = re.compile(rb'/root/(?:go/pkg/mod/|astronomer-all/|\.cache/)[A-Za-z0-9_./@+~%=-]{1,700}\.go')
PREFIXES = re.compile(rb'/root/astronomer-all/[A-Za-z0-9_.-]+/')
OUT = Path('/root/.cache/astronomer-032/qualification/go1266-ar-readonly-' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'))
OUT.mkdir(mode=0o700)
SOURCE = Path(__file__).read_bytes()
(OUT / Path(__file__).name).write_bytes(SOURCE)
(OUT / Path(__file__).name).chmod(0o600)

def identity(s):
    return (s.st_dev, s.st_ino, s.st_size, s.st_mode, s.st_uid, s.st_nlink, s.st_mtime_ns, s.st_ctime_ns)

pool = []
counts = {'examined': 0, 'regularSingleLinkArchivesGo1266': 0, 'notRegularSingleLinkOwned': 0, 'notExactCompilerArchive': 0, 'changed': 0, 'overByteCap': 0}
errors = []
for path in CACHE.glob('[0-9a-f][0-9a-f]/*-d'):
    counts['examined'] += 1
    try:
        before = path.lstat()
        if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_uid != os.getuid():
            counts['notRegularSingleLinkOwned'] += 1
            continue
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        with os.fdopen(fd, 'rb') as stream:
            actual = os.fstat(stream.fileno())
            header = stream.read(4096)
        match = HEADER.search(header)
        if identity(before) != identity(actual) or identity(before) != identity(path.lstat()):
            counts['changed'] += 1
            continue
        if not header.startswith(b'!<arch>\n') or not match:
            counts['notExactCompilerArchive'] += 1
            continue
        counts['regularSingleLinkArchivesGo1266'] += 1
        pool.append((before.st_size, str(path), before, match.group().decode('ascii')))
    except FileNotFoundError:
        counts['changed'] += 1
    except OSError as error:
        errors.append({'path': str(path), 'operation': 'headerInspection', 'errno': error.errno})

records = []
total = 0
for size, name, before, header in sorted(pool, key=lambda item: (-item[0], item[1])):
    if len(records) == LIMIT:
        break
    if total + size > CAP:
        counts['overByteCap'] += 1
        continue
    path = Path(name)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        with os.fdopen(fd, 'rb') as stream:
            actual = os.fstat(stream.fileno())
            if identity(before) != identity(actual):
                counts['changed'] += 1
                continue
            with mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
                current_header = bytes(data[:4096])
                if not current_header.startswith(b'!<arch>\n') or not HEADER.search(current_header):
                    counts['changed'] += 1
                    continue
                digest = hashlib.sha256(data).hexdigest()
                sources = sorted({match.decode('ascii') for match in SOURCES.findall(data)})
                prefixes = sorted({match.decode('ascii') for match in PREFIXES.findall(data)})
        if identity(before) != identity(path.lstat()):
            counts['changed'] += 1
            continue
        records.append({'path': name, 'sha256': digest, 'sizeBytes': size, 'allocatedBytes': before.st_blocks * 512,
                        'device': before.st_dev, 'inode': before.st_ino, 'mode': stat.S_IMODE(before.st_mode),
                        'uid': before.st_uid, 'linkCount': before.st_nlink, 'mtimeNS': before.st_mtime_ns,
                        'ctimeNS': before.st_ctime_ns, 'type': 'ar', 'compilerHeader': header,
                        'observedGoSourcePaths': sources, 'observedFirstPartyPrefixes': prefixes,
                        'changedDuringRead': False})
        total += size
    except FileNotFoundError:
        counts['changed'] += 1
    except OSError as error:
        errors.append({'path': name, 'operation': 'hashProvenanceInspection', 'errno': error.errno})

byinode = {(row['device'], row['inode']): row for row in records}
fdrefs, maps, go_processes = [], [], []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit() or int(proc.name) == os.getpid():
        continue
    pid = int(proc.name)
    try:
        executable = os.readlink(proc / 'exe')
        if Path(executable).name in ('go', 'compile', 'link', 'asm'):
            go_processes.append({'pid': pid, 'executable': executable})
    except (FileNotFoundError, ProcessLookupError):
        pass
    except PermissionError:
        errors.append({'pid': pid, 'operation': 'processExecutablePermissionDenied'})
    try:
        for fd in (proc / 'fd').iterdir():
            try:
                info = fd.stat()
                row = byinode.get((info.st_dev, info.st_ino))
                if row:
                    fdrefs.append({'pid': pid, 'fd': fd.name, 'archivePath': row['path']})
            except (FileNotFoundError, ProcessLookupError):
                pass
            except PermissionError:
                errors.append({'pid': pid, 'operation': 'fdPermissionDenied'})
    except (FileNotFoundError, ProcessLookupError):
        pass
    except PermissionError:
        errors.append({'pid': pid, 'operation': 'fdDirectoryPermissionDenied'})
    try:
        for line in (proc / 'maps').read_text().splitlines():
            parts = line.split(None, 5)
            if len(parts) < 5:
                continue
            major, minor = (int(item, 16) for item in parts[3].split(':'))
            row = byinode.get((os.makedev(major, minor), int(parts[4])))
            if row:
                maps.append({'pid': pid, 'archivePath': row['path']})
    except (FileNotFoundError, ProcessLookupError):
        pass
    except PermissionError:
        errors.append({'pid': pid, 'operation': 'mapsPermissionDenied'})

result = {'schemaVersion': 1, 'status': 'READ_ONLY_INVENTORY_NO_DELETION',
          'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scriptSHA256': hashlib.sha256(SOURCE).hexdigest(), 'cacheRoot': str(CACHE),
          'maximumCandidates': LIMIT, 'maximumLogicalBytes': CAP, 'selection': 'largest exact Go1.26.6 ar files first within count and byte caps',
          'counts': counts, 'candidateCount': len(records), 'logicalBytes': total,
          'allocatedBytes': sum(row['allocatedBytes'] for row in records), 'candidates': records,
          'openCandidateFDs': fdrefs, 'mappedCandidates': maps, 'observedGoCompilerProcesses': go_processes,
          'inspectionErrors': errors, 'limits': ['Read-only observation; no deletion authorized or attempted.',
          'Exact header, regular owned single-link archive and stable stat/hash checks; no ELF or source/module/toolchain files selected.',
          'Observed embedded source paths describe compilation provenance, not a complete dependency or lease proof.',
          'Repeat all identity, compiler header, hash, process and FD/map fences before any separately approved cleanup.']}
path = OUT / 'inventory.json'
path.write_text(json.dumps(result, indent=2) + '\n')
path.chmod(0o600)
print(json.dumps({'inventoryPath': str(path), 'inventorySHA256': hashlib.sha256(path.read_bytes()).hexdigest(),
                  'candidateCount': len(records), 'logicalBytes': total, 'allocatedBytes': result['allocatedBytes'],
                  'openCandidateFDs': len(fdrefs), 'mappedCandidates': len(maps), 'inspectionErrors': len(errors),
                  'observedGoCompilerProcessCount': len(go_processes)}))
