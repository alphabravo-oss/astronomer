import hashlib,importlib.util,json,mmap,os,stat,subprocess,sys,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('cleanup','/tmp/plan032_go1266_ar_cleanup.py');cleanup=importlib.util.module_from_spec(spec);spec.loader.exec_module(cleanup)
class Controls(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='plan032-w07-cleanup-controls-');self.root=Path(self.tmp.name);self.oldcache=cleanup.CACHE;cleanup.CACHE=self.root/'cache';cleanup.CACHE.mkdir();(cleanup.CACHE/'ab').mkdir();self.path=cleanup.CACHE/'ab'/('ab'+'0'*62+'-d');self.path.write_bytes(b'!<arch>\ngo object linux amd64 go1.26.6 GOAMD64=v1 X:fixture\n/root/go/pkg/mod/example.org/tool@v1.0.0/example.go\x00');self.path.chmod(0o600);s=self.path.lstat();self.r=dict(path=str(self.path),sha256=hashlib.sha256(self.path.read_bytes()).hexdigest(),**cleanup.identity(s),type='ar',compilerHeader='go object linux amd64 go1.26.6 GOAMD64=v1 X:fixture',observedGoSourcePaths=['/root/go/pkg/mod/example.org/tool@v1.0.0/example.go'],observedFirstPartyPrefixes=[])
 def tearDown(self):cleanup.CACHE=self.oldcache;self.tmp.cleanup()
 def testExactRegularSourceBoundArchivePasses(self):self.assertEqual(cleanup.validate_record(self.r),self.path)
 def testOtherCompilerRejectedEvenWithOldVersionStringElsewhere(self):
  self.path.write_bytes(self.path.read_bytes().replace(b'go1.26.6 GOAMD64',b'go1.27.2 GOAMD64')+b'\x00go1.26.6')
  self.r.update(cleanup.identity(self.path.lstat()),sha256=hashlib.sha256(self.path.read_bytes()).hexdigest())
  with self.assertRaisesRegex(ValueError,'compiler header'):cleanup.validate_record(self.r)
 def testChangedRecordedHeaderRejected(self):
  self.r['compilerHeader']='go object linux amd64 go1.26.6 wrong'
  with self.assertRaisesRegex(ValueError,'compiler header'):cleanup.validate_record(self.r)
 def testChangedBytesIdentityAndSHARejected(self):
  self.path.write_bytes(self.path.read_bytes()+b'mutation')
  with self.assertRaisesRegex(ValueError,'identity'):cleanup.validate_record(self.r)
 def testChangedSourceProvenanceRejected(self):
  self.path.write_bytes(self.path.read_bytes()+b'/root/astronomer-all/astronomer/internal/new.go');self.r.update(cleanup.identity(self.path.lstat()),sha256=hashlib.sha256(self.path.read_bytes()).hexdigest())
  with self.assertRaisesRegex(ValueError,'provenance'):cleanup.validate_record(self.r)
 def testSymlinkAndHardlinkRejected(self):
  elsewhere=self.root/'same';os.link(self.path,elsewhere)
  with self.assertRaisesRegex(ValueError,'exclusively'):cleanup.validate_record(self.r)
  elsewhere.unlink();self.path.unlink();self.path.symlink_to(elsewhere)
  with self.assertRaisesRegex(ValueError,'exclusively'):cleanup.validate_record(self.r)
 def testELFToolRejectedDespiteReleasedSource(self):
  self.r['type']='elf'
  with self.assertRaisesRegex(ValueError,'ar only'):cleanup.validate_record(self.r)
 def testWrongScopePathRejected(self):
  self.r['path']=str(self.root/'outside')
  with self.assertRaises(ValueError):cleanup.validate_record(self.r)
 def testOpenedChildConsumerRejectedAndJoined(self):
  child=subprocess.Popen([sys.executable,'-c','import sys; f=open(sys.argv[1],"rb");print("ready",flush=True);sys.stdin.read()',str(self.path)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
  try:
   self.assertEqual(child.stdout.readline().strip(),'ready')
   with self.assertRaises(ValueError):cleanup.process_fence([self.r])
  finally:child.communicate('',timeout=5)
  self.assertEqual(child.returncode,0)
 def testManifestValidationDoesNotDeleteAndExactExecuteRemovesOnlyFixture(self):
  out=self.root/'output';out.mkdir(mode=0o700);inv=out/'inventory.json';o=dict(schemaVersion=1,status='READ_ONLY_INVENTORY_NO_DELETION',maximumCandidates=128,maximumLogicalBytes=3*1024**3,candidateCount=1,logicalBytes=self.r['sizeBytes'],cacheRoot=str(cleanup.CACHE),openCandidateFDs=[],mappedCandidates=[],observedGoCompilerProcesses=[],inspectionErrors=[],candidates=[self.r]);inv.write_text(json.dumps(o));sha=hashlib.sha256(inv.read_bytes()).hexdigest();oldargv=sys.argv;oldcapacity=cleanup.capacity;cleanup.capacity=lambda:{'syntheticControl':True}
  try:
   sys.argv=['cleanup','--inventory',str(inv),'--expected-sha256',sha,'--receipt',str(out/'inspect.json')];self.assertEqual(cleanup.main(),0);self.assertTrue(self.path.exists())
   sys.argv+=['--execute'];sys.argv[sys.argv.index('--receipt')+1]=str(out/'execute.json');self.assertEqual(cleanup.main(),0);self.assertFalse(self.path.exists());self.assertTrue(inv.exists())
  finally:sys.argv=oldargv;cleanup.capacity=oldcapacity
if __name__=='__main__':unittest.main(verbosity=2)
