import hashlib,json,subprocess
from pathlib import Path
root=Path('/root/astronomer-all/astronomer-032-w13');out=Path('/tmp/w13-backend-boundary-inventory/427bcf14');head='427bcf141ccb252ab76f29f420162671008c61c3';base='8c2bd83f6927c15ce26715ce0d4677942bb7c806'
def git(*args):return subprocess.run(['git','-C',str(root),*args],capture_output=True,check=True,timeout=30).stdout
paths=git('ls-tree','-r','--name-only',head).decode().splitlines()
exact={'docs/openapi.yaml','frontend/src/types/openapi.generated.ts','frontend/src/lib/api/generated/client.ts'}
prefixes=('pkg/astroclient/','pkg/protocol/','internal/db/queries/','internal/db/queryextensions/','internal/db/sqlc/','internal/db/migrations/')
rows=[]
for p in paths:
 if p not in exact and not p.startswith(prefixes):continue
 data=git('show',head+':'+p);before=git('show',base+':'+p)
 rows.append({'path':p,'sha256':hashlib.sha256(data).hexdigest(),'baseline_sha256':hashlib.sha256(before).hexdigest(),'unchanged':data==before})
assert rows and all(x['unchanged'] for x in rows),'contract source drift must be reviewed'
(out/'contract-source-identity.json').write_text(json.dumps({'schema_version':1,'source':head,'baseline':base,'scope':'Selected public generated consumers/protocol and canonical persistence trees byte comparison. This proves no source changes, not fresh generator/test/runtime acceptance.','paths':rows},indent=2)+'\n')
print(json.dumps({'contract_paths':len(rows),'unchanged':True}))
