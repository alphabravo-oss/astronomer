#!/usr/bin/env python3
"""Source discovery only; reads an immutable tracked Git tree, never executes Go."""
import hashlib,json,re,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]); out=Path(sys.argv[2]); rev=sys.argv[3]
def git(*args):
 return subprocess.run(['git','-C',str(root),*args],check=True,capture_output=True,timeout=30).stdout
head=git('rev-parse',rev).decode().strip()
paths=git('ls-tree','-r','--name-only',head).decode().splitlines()
rows=[]
for path in paths:
 if not path.endswith('.go') or path.endswith('_test.go'): continue
 data=git('show',head+':'+path); text=data.decode(); imports=[]
 for m in re.finditer(r'^import\s+(?:\((.*?)^\)|([^\n]+))',text,re.M|re.S):
  imports.extend(re.findall(r'"([^"\n]+)"',m.group(1) if m.group(1) is not None else m.group(2)))
 calls=[]
 for n,line in enumerate(text.splitlines(),1):
  if re.search(r'\.(?:Begin|BeginTx|Exec|Query|QueryRow|Commit|Rollback|CoreV1|AppsV1|Dynamic|Resource|Namespace|Do|Patch|Delete|List|Create|Update)\(',line):
   calls.append({'line':n,'identifiers':re.findall(r'([A-Za-z_][\w]*(?:\.[A-Za-z_]\w*)+)\(',line)})
 declarations=[]
 if path.startswith('internal/handler/'):
  for m in re.finditer(r'^type\s+(\w+)\s+(interface|struct)\s*\{',text,re.M):
   declarations.append({'name':m.group(1),'kind':m.group(2),'line':text.count('\n',0,m.start())+1})
 rows.append({'path':path,'sha256':hashlib.sha256(data).hexdigest(),'generated':bool(re.search(r'(?m)^// Code generated .*DO NOT EDIT\.',text)),'imports':imports,'canonical_sqlc_import':any(x.endswith('/internal/db/sqlc') for x in imports),'pgx_import':any('github.com/jackc/pgx' in x for x in imports),'kubernetes_import':any(x.startswith('k8s.io/') for x in imports),'handler_dependency_declarations':declarations,'candidate_low_level_calls':calls})
result={'schema_version':1,'source':head,'scope':'All tracked production Go files in this immutable Git tree; _test.go excluded explicitly, generated files retained. Import/declaration/call regex discovery is not receiver-type resolution, whole-callgraph or authorization proof. Manual family traces are separate.','module_count':len(rows),'generated_count':sum(x['generated'] for x in rows),'modules':rows}
out.mkdir(exist_ok=True,parents=True); (out/'imports.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'source':head,'modules':len(rows),'generated':result['generated_count'],'handlers':sum(x['path'].startswith('internal/handler/') for x in rows),'sqlc_importers':sum(x['canonical_sqlc_import'] for x in rows),'pgx_importers':sum(x['pgx_import'] for x in rows),'kubernetes_importers':sum(x['kubernetes_import'] for x in rows)}))
