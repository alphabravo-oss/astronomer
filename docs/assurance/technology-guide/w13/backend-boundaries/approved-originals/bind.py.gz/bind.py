import hashlib,json,subprocess
from pathlib import Path
root=Path('/root/astronomer-all/astronomer-032-w13');out=Path('/tmp/w13-backend-boundary-inventory/427bcf14')
head='427bcf141ccb252ab76f29f420162671008c61c3';base='8c2bd83f6927c15ce26715ce0d4677942bb7c806'
def git(*args):return subprocess.run(['git','-C',str(root),*args],capture_output=True,check=True,timeout=30).stdout
families={
'identity':['internal/handler/auth.go','internal/handler/auth_transactional_audit_test.go','internal/handler/users.go','internal/server/app_identity_cluster.go','internal/handler/user_preferences.go','internal/userpreferences/service.go','internal/userpreferences/receipt.go','internal/userpreferences/row.go','internal/userpreferences/service_test.go','internal/userpreferences/receipt_test.go'],
'sso_settings':['internal/handler/sso.go','internal/handler/sso_tx.go','internal/handler/resources_settings_sso.go','internal/handler/resources_settings_sso_tx.go','internal/handler/platform_settings.go','internal/handler/settings_cache.go'],
'registration':['internal/handler/cluster_registration.go','internal/handler/clusters.go','internal/registration/service.go','internal/registration/transaction.go'],
'resources':['internal/handler/resources.go','internal/server/routes.go','internal/handler/resource_operations.go','internal/handler/node_operations.go'],
'delivery':['internal/server/app_delivery.go','internal/delivery/catalogapp/service.go','internal/delivery/systemrollout/service.go','internal/delivery/builtin/provisioner.go'],
'operations':['internal/ops/upgrade/plan.go','internal/ops/upgrade/machine.go','internal/ops/process/process.go','internal/worker/tasks/cluster_decommission.go'],
'audit':['internal/audit/outbox.go','internal/handler/audit_helpers.go','internal/handler/user_preferences_integrity.go'],
'composition':['internal/server/app_composition_types.go','internal/server/app_runtime_foundation.go','internal/server/app_persistence.go','internal/server/app_kubernetes.go','internal/server/app_integrations.go','internal/server/app_runtime_charlie.go','internal/server/mutation_tx.go','internal/handler/mutation.go','docs/architecture/dependency-boundaries.json','docs/architecture/complexity-baseline.json'],
'preserved_agent_tunnel_charlie':['internal/agent/delivery/executor.go','internal/agent/delivery/materializer.go','internal/agent/delivery/runtime.go','internal/agent/delivery/checkpoint.go','internal/agent/delivery/runtime_test.go','internal/agent/delivery/runtime_assignment_observation_test.go','internal/agent/delivery/checkpoint_test.go','internal/agent/delivery/executor_test.go','internal/agent/delivery/materializer_test.go','internal/tunnel/locator.go','internal/tunnel/locator_test.go','internal/tunnel/server_supersede_locator_test.go','internal/charlie/contract/client.go','internal/charlie/contract/verify.go','internal/charlie/contract/contract_test.go','internal/charlie/contract/runtime_test.go','internal/charlie/contract/revocation_test.go']}
paths=set(git('ls-tree','-r','--name-only',head).decode().splitlines())
missing=[p for ps in families.values() for p in ps if p not in paths]
if missing:print(json.dumps({'missing':missing}));raise SystemExit(1)
bindings=[]
for family,ps in families.items():
 for p in ps:
  data=git('show',head+':'+p)
  try:before=git('show',base+':'+p)
  except subprocess.CalledProcessError:before=None
  bindings.append({'family':family,'path':p,'sha256':hashlib.sha256(data).hexdigest(),'baseline_sha256':hashlib.sha256(before).hexdigest() if before is not None else None,'unchanged_from_characterization_baseline':before==data})
changed=git('diff','--name-only',base,head).decode().splitlines()
production=[p for p in changed if p.endswith('.go') and not p.endswith('_test.go')]
result={'schema_version':1,'source':head,'characterization_baseline':base,'scope':'Manual family and preserved adjacent contract source bindings. Test bindings prove unchanged source, not a fresh runtime run. All production Go differences from baseline are listed.','bindings':bindings,'all_changed_production_go_paths_from_baseline':production,'preserved_agent_tunnel_charlie_byte_equal':all(x['unchanged_from_characterization_baseline'] for x in bindings if x['family']=='preserved_agent_tunnel_charlie')}
(out/'source-bindings.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'bound_paths':len(bindings),'changed_production_paths':production,'preserved_contract_sources_equal':result['preserved_agent_tunnel_charlie_byte_equal']}))
