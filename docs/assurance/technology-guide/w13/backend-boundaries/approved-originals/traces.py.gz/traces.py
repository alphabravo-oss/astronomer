import hashlib,json,subprocess
from pathlib import Path
root=Path('/root/astronomer-all/astronomer-032-w13');out=Path('/tmp/w13-backend-boundary-inventory/427bcf14');source='427bcf141ccb252ab76f29f420162671008c61c3'
# Manually reviewed caller/boundary markers, not inferred receiver/callgraph resolution.
markers=[
('identity','internal/server/app_identity_cluster.go','authHandler.SetRunTx(sqlcMutationTxRunner[handler.AuthMutationTx](database))'),
('preferences','internal/server/app_identity_cluster.go','authHandler.SetUserPreferences(queries, sqlcMutationTxRunner[handler.UserPreferencesMutationTx](database))'),
('preferences','internal/handler/user_preferences.go','reqctx.AuthenticatedUser(r.Context())'),
('preferences','internal/userpreferences/service.go','s.runTx(ctx, func(q MutationTx) error {'),
('preferences','internal/userpreferences/service.go','audit.RecordIntent(ctx, q, intent)'),
('sso','internal/handler/sso_tx.go','q.GetUserByIDForUpdate(r.Context(), user.ID)'),
('sso','internal/handler/sso_tx.go','auth.SyncUserGroups(r.Context(), q, user.ID, connector, info.Groups, true)'),
('sso','internal/handler/resources_settings_sso_tx.go','q.LockSSOProviderKey(r.Context(), params.Provider)'),
('sso','internal/handler/resources_settings_sso_tx.go','current.Provider != created.Provider'),
('registration','internal/server/app_identity_cluster.go','hub.SetRegistrationAdvancer(clusterRegistrationHandler.Service())'),
('registration','internal/registration/transaction.go','txService, flushEffects := s.Buffered(q)'),
('registration','internal/registration/transaction.go','if !executed || flush == nil'),
('resources','internal/server/app_integrations.go','resourceHandler.SetAuthorization(rbacEngine, rbacQuerier)'),
('resources','internal/server/app_integrations.go','resourceHandler.SetResourceMutationRunTx(sqlcMutationTxRunner[handler.ResourceMutationTx](database))'),
('resources','internal/handler/resources.go','h.requester.Do(ctx, clusterID, method, path, body, headers)'),
('resources','internal/handler/resource_operations.go','q.CreateResourceOperationIdempotent(r.Context(),'),
('delivery','internal/server/app_delivery.go','deliverycatalogapp.New(database.Pool(), deliveryPlanningStore, deliveryPlanner)'),
('delivery','internal/delivery/catalogapp/service.go','s.pool.BeginTx(ctx, pgx.TxOptions{IsoLevel: pgx.Serializable})'),
('delivery','internal/server/app_delivery.go','database.Pool(), deliveryPlanningStore, deliveryPlanner, clusterRegistrationHandler.Service(), catalogLoader'),
('operations','internal/ops/upgrade/machine.go','state.Pending = stage'),
('operations','internal/ops/upgrade/machine.go','m.Driver.Fence(bounded, plan.Identity, plan.Replace)'),
('audit','internal/audit/outbox.go','func RecordIntent(ctx context.Context, q OutboxQuerier, intent Intent) error'),
('composition','internal/server/mutation_tx.go','any(sqlc.New(tx)).(T)'),
('agent_ssa','internal/agent/delivery/executor.go','types.ApplyPatchType'),
('agent_tombstone','internal/agent/delivery/materializer.go','tombstone.DeploymentID != assignment.DeploymentID || tombstone.Generation <= assignment.Generation'),
('agent_offline','internal/agent/delivery/runtime.go','loaded, err := r.store.Load(ctx)'),
('tunnel_generation','internal/tunnel/locator.go','func (l *Locator) refreshTick(ctx context.Context, clusterID string, gen uint64)'),
('charlie','internal/charlie/contract/client.go','localTLS.MinVersion = tls.VersionTLS13'),
('charlie','internal/charlie/contract/client.go','return NewLocalClient(availability, namespace, expectedServerIdentity, tlsConfig)'),
]
rows=[]
for family,p,marker in markers:
 data=subprocess.run(['git','-C',str(root),'show',source+':'+p],check=True,capture_output=True,timeout=30).stdout
 text=data.decode();positions=[i+1 for i,line in enumerate(text.splitlines()) if marker in line]
 if not positions:raise ValueError('missing source marker: '+p+' '+marker)
 rows.append({'family':family,'path':p,'source_sha256':hashlib.sha256(data).hexdigest(),'marker':marker,'lines':positions})
(out/'traces.json').write_text(json.dumps({'schema_version':1,'source':source,'scope':'Exact line markers support manually reviewed boundary traces. This is not executable callgraph or authorization proof.','traces':rows},indent=2)+'\n')
print(json.dumps({'traces':len(rows)}))
