"""Source-only exact preference before inventory; not a runtime runner."""
import json
from pathlib import Path
import re

PACKAGE='github.com/alphabravocompany/astronomer-go/internal/handler'
CHAR_PARENTS=('TestUserPreferencesCharacterizationSelfIdentityBoundary','TestUserPreferencesCharacterizationOptionalNormalization','TestUserPreferencesCharacterizationAuditShapeAndRetryKey','TestUserPreferencesCharacterizationCancelledTransactionContext')
CHAR_EXPECTED={name:'pass' for name in CHAR_PARENTS}
CHAR_EXPECTED.update({CHAR_PARENTS[1]+'/'+mode:'pass' for mode in ('omitted','null','empty')})
PG_PARENTS=('TestPreferencePostgresMissingReadIsActorScopedAndHasNoWrites','TestPreferencePostgresRequiredFavoritesRejectBeforeMutation','TestPreferencePostgresAuditFailureRollsBackActualReplacementAndRetry','TestPreferencePostgresChangedBodySameKeyCannotRetainStaleAudit','TestPreferencePostgresChangedBodySameRequestIDCannotRetainStaleAudit')
PG_EXPECTED={name:('pass' if i in (0,2) else 'fail') for i,name in enumerate(PG_PARENTS)}
PG_EXPECTED.update({PG_PARENTS[1]+'/'+mode:('pass' if mode=='empty' else 'fail') for mode in ('missing','null','empty')})
PG_EXPECTED.update({PG_PARENTS[4]+'/'+mode:'fail' for mode in ('absent-header','invalid-header','repeated-header')})
DIAGNOSTICS={PG_PARENTS[1]+'/'+mode:'invalid required favorites reached the SQL array constraint instead of safe request validation' for mode in ('missing','null')}
DIAGNOSTICS[PG_PARENTS[3]]='changed-body same-key replay replaced preferences while retaining the first audit detail'
DIAGNOSTICS.update({PG_PARENTS[4]+'/'+mode:'same request ID without a valid idempotency key silently replaced preferences while retaining only the old audit detail' for mode in ('absent-header','invalid-header','repeated-header')})

def verify(log:Path, postgres:bool):
 expected=PG_EXPECTED if postgres else CHAR_EXPECTED
 diagnostics=DIAGNOSTICS if postgres else {}
 rows=[]
 for line in log.read_text().splitlines():
  row=json.loads(line)
  assert isinstance(row,dict) and row.get('Action') in {'start','run','pause','cont','output','pass','fail','skip','build-output','build-fail'},'non-event output'
  rows.append(row)
 named=[row for row in rows if row['Action'] in ('pass','fail','skip') and row.get('Test')]
 assert len(named)==len(expected) and {row['Test'] for row in named}==set(expected),'named inventory drift'
 assert all(row.get('Package')==PACKAGE and row['Action']==expected[row['Test']] for row in named),'named package or outcome drift'
 packages=[row for row in rows if row['Action'] in ('pass','fail','skip') and not row.get('Test')]
 assert len(packages)==1 and packages[0].get('Package')==PACKAGE and packages[0]['Action']==('fail' if postgres else 'pass'),'package terminal drift'
 actual={}
 for row in rows:
  if row['Action']!='output':continue
  for line in row.get('Output','').splitlines():
   match=re.fullmatch(r'\s*[A-Za-z0-9_]+\.go:\d+: (.+)',line)
   if match:
    assert row.get('Package')==PACKAGE,'diagnostic package drift'
    actual.setdefault(row.get('Test'),[]).append(match.group(1))
 assert actual=={name:[message] for name,message in diagnostics.items()},'intended boundary diagnostic absent or setup/cleanup fault present'
 return {'named_passes':sum(v=='pass' for v in expected.values()),'named_failures':sum(v=='fail' for v in expected.values()),'skips':0,'package_outcome':packages[0]['Action']}
