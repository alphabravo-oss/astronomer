"""Unlaunched after-only proposal using the reviewed held-leader runner."""
import argparse
import hashlib
import importlib.util
import json
import os
import re
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path('/root/astronomer-all/astronomer-032-w13')
SOURCE='debc4313'
REVIEWED=Path('/tmp/w07-after-query-ee2c52d8/run_after.py')
assert hashlib.sha256(REVIEWED.read_bytes()).hexdigest()=='4b1037ee327b96de13338c5ab8ba1366e5a6bec007f0c8cf634faf50dfaace46'
spec=importlib.util.spec_from_file_location('reviewed_after',REVIEWED);after=importlib.util.module_from_spec(spec);spec.loader.exec_module(after)
after.ROOT=ROOT
VERIFIER=Path('/tmp/w13-preference-before-parser-proposal/verify_before.py')
VERIFIER_SHA='34f3dcbc0f99c4178c3d72cf06164c407f342fa185319e9de9303454b3185e1a'
assert hashlib.sha256(VERIFIER.read_bytes()).hexdigest()==VERIFIER_SHA
spec=importlib.util.spec_from_file_location('preference_verifier',VERIFIER);verifier=importlib.util.module_from_spec(spec);spec.loader.exec_module(verifier)
PENDING_FIXTURES={
 'internal/handler/user_preferences_postgres_boundary_test.go': '5534f5707cbd9beee982197f6fdbcc960c37e3eeb329b15ea351d17a81ec4d53',
 'internal/handler/user_preferences_request_id_boundary_test.go': 'f1d8eaa9bc0f4787dff09243f81cdfa8e21d7b1e073e8f9c305e16fd3edbb4d0',
 'internal/handler/user_preferences_receipt_postgres_test.go': '03ab4ff7e84c423ac15d29389c859ad2ccff44c5caf1b6909ed8347e3781389b',
 'internal/handler/user_preferences_concurrency_postgres_test.go': '09c95e19c2cd971794954ab2c6b1a965470389156847806a0fffba692e3110c7',
}


PURE_PARENTS=('TestPreferenceKeyReturnsCommittedDocumentWithoutRepeatingWrites','TestPreferenceReceiptReaderRejectsCorruptStateAndSeparatesBodyConflict','TestPreferenceReceiptReservationRejectsPartialState','TestPreferenceReceiptWriterBoundsBeforeAttachment')
PURE_EXPECTED={name:'pass' for name in PURE_PARENTS}
PURE_EXPECTED.update({PURE_PARENTS[1]+'/'+mode:'pass' for mode in ('valid','changed-request','wrong-version','wrong-actor','wrong-method','wrong-path','wrong-resource','wrong-table','body-digest-mismatch','null-favorites','null-optional','unknown-field','duplicate-field','trailing-value','oversized')})
PURE_EXPECTED.update({PURE_PARENTS[2]+'/'+mode:'pass' for mode in ('fresh','nonempty-table','nonempty-response','null-response','empty-response','array-response')})
HANDLER_PARENTS=verifier.CHAR_PARENTS+PURE_PARENTS
HANDLER_EXPECTED={**verifier.CHAR_EXPECTED,**PURE_EXPECTED}
DOMAIN_PACKAGE='github.com/alphabravocompany/astronomer-go/internal/userpreferences'
DOMAIN_PARENT='TestNormalizeOptionalPreservesRequiredFavoritesBoundary'
DOMAIN_EXPECTED={DOMAIN_PARENT:'pass',**{DOMAIN_PARENT+'/'+mode:'pass' for mode in ('missing','empty','populated')}}
PG_PARENTS=verifier.PG_PARENTS+('TestPreferencePostgresAttachmentFailureRollsBackReplacementAuditAndReservation','TestPreferencePostgresReplayReturnsReceiptWithoutOverwritingLaterReplacement','TestPreferencePostgresConcurrentKeysSerializeActualReplacementAndAudit')
PG_EXPECTED={name:'pass' for name in verifier.PG_EXPECTED}
PG_EXPECTED.update({name:'pass' for name in PG_PARENTS[-3:]})
PG_EXPECTED.update({PG_PARENTS[-1]+'/'+mode:'pass' for mode in ('equal-body','changed-body')})

def verify_pass(log,expected,package=verifier.PACKAGE):
    original_expected,original_package=verifier.CHAR_EXPECTED,verifier.PACKAGE
    try:
        verifier.CHAR_EXPECTED=expected;verifier.PACKAGE=package
        return verifier.verify(log,False)
    finally:
        verifier.CHAR_EXPECTED=original_expected;verifier.PACKAGE=original_package

GO_IDENTITY={'path': '/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.linux-amd64/bin/go', 'sha256': '548d3c32f83fa81152f543eb1526be7884cfe0526eb5e9ce29d3eca14786e7e0', 'device': 2049, 'inode': 2360704, 'size': 17164055, 'mtime_ns': 1791570925918518586}
GO=Path(GO_IDENTITY['path'])
def go_identity():
    assert not GO.is_symlink(), 'selected Go binary symlink drift'
    stat=GO.stat()
    return {'path':str(GO),'sha256':hashlib.sha256(GO.read_bytes()).hexdigest(),'device':stat.st_dev,'inode':stat.st_ino,'size':stat.st_size,'mtime_ns':stat.st_mtime_ns}

def assert_go_identity():
    assert go_identity()==GO_IDENTITY, 'selected Go binary identity drift'

def interrupt(_number,_frame):
    for number in (signal.SIGTERM,signal.SIGINT):signal.signal(number,signal.SIG_IGN)
    raise RuntimeError('owned lane interrupted')

def step_timeout(name,deadline):
    remaining=deadline-time.monotonic()
    assert remaining>0, 'overall owned lane deadline'
    return min(30 if name=='go-version' else 600,remaining)

def assert_fixtures():
    for name,digest in PENDING_FIXTURES.items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,'approved witness fixture mismatch'

def live_fixture_fence(major,database_url):
    assert after.fences.expected_schema_version(ROOT)==77,'exact fixture schema mismatch'
    observed_url,observation=after.fences.live_fence(major,77,database_url)
    assert observed_url==database_url,'private fixture authority changed'
    return observation

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('major',type=int,choices=(17,18))
    parser.add_argument('private_reference',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    output=args.output;os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve()),'receipt must be outside source'
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    deadline=time.monotonic()+2460
    source=subprocess.check_output(['git','rev-parse',SOURCE],cwd=ROOT,timeout=10).decode().strip()
    receipt={'source':source,'major':args.major,'schema':77,'private_reference':str(args.private_reference),'steps':[],'scope':'32 pure/handler characterization tests, four domain normalization tests and16 real PostgreSQL tests; outer fixtures roll back, concurrency fixture uses an owned synthetic committed actor with exact bounded cleanup; no DDL or customer data'}
    database_url=None
    def guard(stage):
        check=subprocess.run(['bash','scripts/check-build-capacity.sh','--json'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15)
        with (output/'capacity.jsonl').open('a') as stream:stream.write(json.dumps({'stage':stage,'time':time.time(),'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr})+'\n')
        assert check.returncode==0,'fatal capacity guard'
    def ownership():
        assert_go_identity()
        assert_fixtures()
        receipt['owned_fence']=live_fixture_fence(args.major,database_url)
        assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,timeout=10)==b''
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,timeout=10).decode().strip()==source
    handlers={number:signal.signal(number,interrupt) for number in (signal.SIGTERM,signal.SIGINT)}
    try:
        guard('initial');database_url=after.fences.private_read(args.private_reference)['database_url'];ownership();receipt['go_before']=go_identity();receipt['source_before']=after.fences.fingerprint(ROOT)
        env=dict(os.environ,GOTOOLCHAIN='go1.27.2',GOWORK='off',GOMAXPROCS='4',GOFLAGS='-p=2')
        env['PATH']=str(GO.parent)+':'+env['PATH']
        env['PAGINATION_TEST_DATABASE_URL']=database_url
        race=['-race'] if args.major==18 else []
        commands=[('go-version',[str(GO),'version']),
          ('handler-pure',[str(GO),'test',*race,'-json','-count=1','-run','^('+'|'.join(HANDLER_PARENTS)+')$','./internal/handler']),
          ('domain-pure',[str(GO),'test',*race,'-json','-count=1','-run','^'+DOMAIN_PARENT+'$','./internal/userpreferences']),
          ('postgres-after',[str(GO),'test',*race,'-json','-count=1','-run','^('+'|'.join(PG_PARENTS)+')$','./internal/handler']),
          ('vet',[str(GO),'vet','./internal/handler','./internal/userpreferences'])]
        for name,command in commands:
            step=after.run_step(command,command,env,output/(name+'.log'),guard,ownership,lambda:after.fences.fingerprint(ROOT),timeout=step_timeout(name,deadline))
            receipt['steps'].append({'name':name,**step})
            result=step.get('outcome') or {}
            assert step['source_stable'] and step['final_guard_pass'] and result.get('drained') and not result.get('reason'),'ownership/source/guard fault'
            if name=='go-version':
                assert after.passed(step) and (output/'go-version.log').read_text().strip()=='go version go1.27.2 linux/amd64'
            else:
                assert after.passed(step),'after gate failed'
                if name=='handler-pure':receipt['handler_events']=verify_pass(output/(name+'.log'),HANDLER_EXPECTED)
                elif name=='domain-pure':receipt['domain_events']=verify_pass(output/(name+'.log'),DOMAIN_EXPECTED,DOMAIN_PACKAGE)
                elif name=='postgres-after':receipt['postgres_events']=verify_pass(output/(name+'.log'),PG_EXPECTED)
    except BaseException as error:receipt['failure_category']=type(error).__name__
    finally:
        try:
            receipt['go_after']=go_identity()
            assert receipt['go_after']==GO_IDENTITY and receipt.get('go_before')==GO_IDENTITY, 'selected Go binary identity drift'
            receipt['source_after']=after.fences.fingerprint(ROOT)
            receipt['source_stable']=receipt.get('source_before')==receipt['source_after']
            guard('runner-final');receipt['runner_final_guard_pass']=True
        except BaseException as error:receipt['final_failure_category']=type(error).__name__
        (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        for number,handler in handlers.items():signal.signal(number,handler)
    qualified=len(receipt['steps'])==5 and all(name in receipt for name in ('handler_events','domain_events','postgres_events')) and receipt.get('source_stable') and receipt.get('runner_final_guard_pass') and 'failure_category' not in receipt and 'final_failure_category' not in receipt
    print(json.dumps({'receipt':str(output/'receipt.json'),'after_qualified':bool(qualified)}))
    return 0 if qualified else 1

if __name__=='__main__':raise SystemExit(main())
