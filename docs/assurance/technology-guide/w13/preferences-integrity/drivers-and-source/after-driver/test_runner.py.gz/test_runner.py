import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('runner',Path(__file__).with_name('run_after.py'))
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)

class InventoryControls(unittest.TestCase):
 def rows(self,expected,package):
  return [{'Action':'pass','Package':package,'Test':name} for name in expected]+[{'Action':'pass','Package':package}]
 def verify(self,rows,expected,package):
  with tempfile.TemporaryDirectory() as temp:
   log=Path(temp)/'log';log.write_text('\n'.join(json.dumps(row) for row in rows)+'\n')
   return r.verify_pass(log,expected,package)
 def test_all_three_exact_inventories(self):
  for expected,package,count in ((r.HANDLER_EXPECTED,r.verifier.PACKAGE,32),(r.DOMAIN_EXPECTED,r.DOMAIN_PACKAGE,4),(r.PG_EXPECTED,r.verifier.PACKAGE,16)):
   self.assertEqual(len(expected),count)
   self.assertEqual(self.verify(self.rows(expected,package),expected,package)['named_passes'],count)
 def test_missing_or_extra(self):
  rows=self.rows(r.PG_EXPECTED,r.verifier.PACKAGE)
  for altered in (rows[1:],rows+[{'Action':'pass','Package':r.verifier.PACKAGE,'Test':'Unexpected'}]):
   with self.assertRaises(AssertionError):self.verify(altered,r.PG_EXPECTED,r.verifier.PACKAGE)
 def test_duplicate(self):
  rows=self.rows(r.PG_EXPECTED,r.verifier.PACKAGE)
  with self.assertRaises(AssertionError):self.verify(rows+[rows[0]],r.PG_EXPECTED,r.verifier.PACKAGE)
 def test_fail_skip_or_wrong_package(self):
  for field,value in (('Action','fail'),('Action','skip'),('Package','other')):
   rows=self.rows(r.PG_EXPECTED,r.verifier.PACKAGE);rows[0][field]=value
   with self.assertRaises(AssertionError):self.verify(rows,r.PG_EXPECTED,r.verifier.PACKAGE)
 def test_contradictory_package(self):
  rows=self.rows(r.PG_EXPECTED,r.verifier.PACKAGE)
  with self.assertRaises(AssertionError):self.verify(rows+[{'Action':'fail','Package':r.verifier.PACKAGE}],r.PG_EXPECTED,r.verifier.PACKAGE)
 def test_cleanup_or_setup_diagnostic(self):
  rows=self.rows(r.PG_EXPECTED,r.verifier.PACKAGE);rows.append({'Action':'output','Package':r.verifier.PACKAGE,'Test':next(iter(r.PG_EXPECTED)),'Output':'    fixture.go:42: cleanup failed\n'})
  with self.assertRaises(AssertionError):self.verify(rows,r.PG_EXPECTED,r.verifier.PACKAGE)
 def test_non_event(self):
  rows=self.rows(r.PG_EXPECTED,r.verifier.PACKAGE);rows.append({'not':'an event'})
  with self.assertRaises(AssertionError):self.verify(rows,r.PG_EXPECTED,r.verifier.PACKAGE)

if __name__=='__main__':unittest.main()
