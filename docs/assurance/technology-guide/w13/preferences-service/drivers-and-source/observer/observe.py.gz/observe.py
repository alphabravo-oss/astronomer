"""Queued read-only numeric observation; no authority to terminate backends."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess

ROOT = Path('/root/astronomer-all/astronomer-032-w13')
HELPER = Path('/tmp/w07-after-query-ee2c52d8/run_after.py')
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == '4b1037ee327b96de13338c5ab8ba1366e5a6bec007f0c8cf634faf50dfaace46'
spec = importlib.util.spec_from_file_location('approved_after', HELPER)
after = importlib.util.module_from_spec(spec)
spec.loader.exec_module(after)
after.ROOT = ROOT
QUERY = """WITH clients AS (
 SELECT pid, state FROM pg_stat_activity
 WHERE datname = current_database() AND backend_type = 'client backend'
   AND pid <> pg_backend_pid()
)
SELECT (SELECT count(*) FROM clients),
       (SELECT count(*) FROM clients WHERE state IN ('idle in transaction', 'idle in transaction (aborted)')),
       (SELECT count(DISTINCT l.pid) FROM pg_locks l JOIN clients c ON c.pid = l.pid WHERE NOT l.granted)
"""

def parse_counts(text):
    fields = text.strip().split(',')
    assert len(fields) == 3 and all(value.isascii() and value.isdecimal() for value in fields), 'unexpected numeric observation'
    clients, idle, pending = map(int, fields)
    assert idle <= clients and pending <= clients, 'inconsistent numeric observation'
    return {'other_client_backends': clients, 'idle_in_transaction_clients': idle, 'pending_lock_clients': pending}

def interrupt(_number, _frame):
    for number in (signal.SIGINT, signal.SIGTERM):
        signal.signal(number, signal.SIG_IGN)
    raise RuntimeError('observation interrupted')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('major', type=int, choices=(17, 18))
    parser.add_argument('reference', type=Path)
    parser.add_argument('source')
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    os.umask(0o077)
    assert not args.output.resolve().is_relative_to(ROOT.resolve())
    args.output.mkdir(mode=0o700, parents=True, exist_ok=False)
    receipt = {'major': args.major, 'schema': 77, 'private_reference': str(args.reference), 'scope': 'read-only counts in the owned cursor database; self backend excluded; not attribution or absence proof for arbitrary other clients'}
    url = None
    def guard(stage):
        result = subprocess.run(['bash', 'scripts/check-build-capacity.sh', '--json'], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15)
        with (args.output/'capacity.jsonl').open('a') as stream:
            stream.write(json.dumps({'stage':stage, 'exit':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr})+'\n')
        assert result.returncode == 0, 'fatal capacity guard'
    def ownership():
        assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, timeout=10) == b''
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, timeout=10).decode().strip() == args.source
        assert after.fences.expected_schema_version(ROOT) == 77
        connected, observation = after.fences.live_fence(args.major, 77, url)
        assert connected == url
        receipt['owned_fence'] = observation
    handlers = {number:signal.signal(number, interrupt) for number in (signal.SIGINT, signal.SIGTERM)}
    try:
        guard('initial')
        url = after.fences.private_read(args.reference)['database_url']
        ownership()
        env = after.psql_env(url)
        env.update(PGOPTIONS='-c statement_timeout=15000 -c lock_timeout=5000', PGAPPNAME='plan032-w13-post-child-observation')
        command = ['psql', '-X', '-At', '-F', ',', '-v', 'ON_ERROR_STOP=1', '-c', QUERY]
        receipt['source_before'] = after.fences.fingerprint(ROOT)
        step = after.run_step(command, command, env, args.output/'counts.log', guard, ownership, lambda:after.fences.fingerprint(ROOT), timeout=20)
        receipt['step'] = step
        assert after.passed(step) and step['source_stable'] and step['final_guard_pass']
        receipt['counts'] = parse_counts((args.output/'counts.log').read_text())
    except BaseException as error:
        receipt['failure_category'] = type(error).__name__
    finally:
        try:
            receipt['source_after'] = after.fences.fingerprint(ROOT)
            receipt['source_stable'] = receipt.get('source_before') == receipt['source_after']
            guard('runner-final')
            receipt['runner_final_guard_pass'] = True
        except BaseException as error:
            receipt['final_failure_category'] = type(error).__name__
        (args.output/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
        for number, handler in handlers.items():signal.signal(number, handler)
    ok = 'counts' in receipt and receipt.get('source_stable') and receipt.get('runner_final_guard_pass') and 'failure_category' not in receipt and 'final_failure_category' not in receipt
    print(json.dumps({'receipt':str(args.output/'receipt.json'), 'numeric_observation_complete':ok}))
    return 0 if ok else 1

if __name__ == '__main__':raise SystemExit(main())
