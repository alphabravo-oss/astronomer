"""Only the exact reviewed AST tool may replace go run; no compile fallback."""
import hashlib,runpy,subprocess
from pathlib import Path
ROOT=Path('/root/astronomer-all/astronomer-032-w02-grafana-counts')
TOOL=Path('/root/.cache/go-build/7c/7cf966d9f1c4495df190ca35356460cb891b57a7e85d3011df0d3ee0e3c17d85-d/json-governance')
assert hashlib.sha256(TOOL.read_bytes()).hexdigest()=='7cf966d9f1c4495df190ca35356460cb891b57a7e85d3011df0d3ee0e3c17d85'
original=subprocess.check_output
def bounded_cached(command,*args,**kwargs):
    if command==['go','run','./tools/json-governance']:
        return original([str(TOOL)],*args,**kwargs)
    raise AssertionError('unexpected subprocess; no Go fallback')
subprocess.check_output=bounded_cached
runpy.run_path(str(ROOT/'scripts/check-json-governance.py'),run_name='__main__')
