"""Unlaunched before-only proposal using the reviewed held-leader runner."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path('/root/astronomer-all/astronomer-032-w02-grafana-counts')
SOURCE='03449c87'
REVIEWED=Path('/tmp/w07-after-query-ee2c52d8/run_after.py')
assert hashlib.sha256(REVIEWED.read_bytes()).hexdigest()=='4b1037ee327b96de13338c5ab8ba1366e5a6bec007f0c8cf634faf50dfaace46'
spec=importlib.util.spec_from_file_location('reviewed_after',REVIEWED);after=importlib.util.module_from_spec(spec);spec.loader.exec_module(after)
after.ROOT=ROOT
PARENTS=('TestGrafanaMetadataNumericBoundaryBeforeDatasourceEffects','TestGrafanaMetadataNumericBoundaryBeforeFolderEffects')
PACKAGE='github.com/alphabravocompany/astronomer-go/internal/handler'
EXPECTED={name for parent in PARENTS for name in [parent,*[parent+'/'+value for value in ('2147483648','-2147483649','1.25')]]}

def verify_before(log):
    rows=[]
    for line in log.read_text().splitlines():
        row=json.loads(line)
        assert isinstance(row,dict) and row.get('Action') in {'start','run','pause','cont','output','pass','fail','skip','build-output','build-fail'},'non-event output'
        rows.append(row)
    events=[row for row in rows if row['Action'] in ('pass','fail','skip') and row.get('Test')]
    assert len(events)==len(EXPECTED) and {row['Test'] for row in events}==EXPECTED,'unexpected named inventory'
    assert all(row['Action']=='fail' and row.get('Package')==PACKAGE for row in events),'before package or outcome drift'
    package=[row for row in rows if row['Action'] in ('pass','fail','skip') and not row.get('Test')]
    assert len(package)==1 and package[0]['Action']=='fail' and package[0].get('Package')==PACKAGE,'package terminal drift'
    return {'parent_failures':len(PARENTS),'leaf_failures':len(EXPECTED)-len(PARENTS),'skips':0,'package_failures':1}

def main():
    assert len(sys.argv)==2
    output=Path(sys.argv[1]);os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve()),'receipt must be outside source'
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    source=subprocess.check_output(['git','rev-parse',SOURCE],cwd=ROOT,timeout=10).decode().strip()
    receipt={'source':source,'steps':[],'scope':'two before parents only; no product or database mutations'}
    def guard(stage):
        check=subprocess.run(['bash','scripts/check-build-capacity.sh','--json'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15)
        with (output/'capacity.jsonl').open('a') as stream:stream.write(json.dumps({'stage':stage,'time':time.time(),'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr})+'\n')
        assert check.returncode==0,'fatal capacity guard'
    def ownership():
        assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,timeout=10)==b''
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,timeout=10).decode().strip()==source
    def interrupt(_number,_frame):raise RuntimeError('owned before lane interrupted')
    handlers={number:signal.signal(number,interrupt) for number in (signal.SIGTERM,signal.SIGINT)}
    try:
        guard('initial');ownership();receipt['source_before']=after.fences.fingerprint(ROOT)
        env=dict(os.environ,GOTOOLCHAIN='go1.27.2',GOWORK='off',GOMAXPROCS='4',GOFLAGS='-p=2')
        env['PATH']='/usr/local/go/bin:'+env['PATH']
        for name,command in [('go-version',['/usr/local/go/bin/go','version']),('before',['/usr/local/go/bin/go','test','-json','-count=1','-run','^('+'|'.join(PARENTS)+')$','./internal/handler'])]:
            step=after.run_step(command,command,env,output/(name+'.log'),guard,ownership,lambda:after.fences.fingerprint(ROOT),timeout=600)
            receipt['steps'].append({'name':name,**step})
            result=step.get('outcome') or {}
            assert step['source_stable'] and step['final_guard_pass'] and result.get('drained') and not result.get('reason'),'ownership/source/guard fault'
            if name=='go-version':
                assert after.passed(step) and (output/'go-version.log').read_text().strip()=='go version go1.27.2 linux/amd64'
            else:
                assert result['exitCode']==1,'expected before failure absent'
                receipt['events']=verify_before(output/'before.log')
    except BaseException as error:receipt['failure_category']=type(error).__name__
    finally:
        try:
            receipt['source_after']=after.fences.fingerprint(ROOT)
            receipt['source_stable']=receipt.get('source_before')==receipt['source_after']
            guard('runner-final');receipt['runner_final_guard_pass']=True
        except BaseException as error:receipt['final_failure_category']=type(error).__name__
        (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        for number,handler in handlers.items():signal.signal(number,handler)
    qualified=len(receipt['steps'])==2 and 'events' in receipt and receipt.get('source_stable') and receipt.get('runner_final_guard_pass') and 'failure_category' not in receipt and 'final_failure_category' not in receipt
    print(json.dumps({'receipt':str(output/'receipt.json'),'expected_before_failure_qualified':bool(qualified)}))
    return 0 if qualified else 1

if __name__=='__main__':raise SystemExit(main())
