import importlib.util,json,tempfile,unittest
from pathlib import Path
s=importlib.util.spec_from_file_location('runner',Path(__file__).with_name('run_before.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)

class InventoryTest(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.log=Path(self.temp.name)/'events.log'
  self.rows=[{'Action':'fail','Test':name,'Package':r.PACKAGE} for name in sorted(r.EXPECTED)]+[{'Action':'fail','Package':r.PACKAGE}]
 def check(self):
  self.log.write_text(''.join(json.dumps(row)+'\n' for row in self.rows));return r.verify_before(self.log)
 def test_exact_inventory(self):self.assertEqual(self.check(),{'parent_failures':2,'leaf_failures':6,'skips':0,'package_failures':1})
 def test_missing_duplicate_extra_pass_and_skip_rejected(self):
  original=list(self.rows)
  for change in ['missing','duplicate','extra','pass','skip','package']:
   self.rows=[dict(row) for row in original]
   if change=='missing':self.rows.pop(0)
   if change=='duplicate':self.rows.append(self.rows[0])
   if change=='extra':self.rows[0]['Test']='unapproved'
   if change in ('pass','skip'):self.rows[0]['Action']=change
   if change=='package':self.rows.pop()
   with self.subTest(change=change),self.assertRaises(AssertionError):self.check()
 def test_missing_wrong_package_and_contradictory_terminals(self):
  original=list(self.rows)
  for change in ['missing-test-package','wrong-test-package','missing-package','wrong-package','extra-pass-package','extra-skip-package','duplicate-package','non-event']:
   self.rows=[dict(row) for row in original]
   if change=='missing-test-package':self.rows[0].pop('Package')
   if change=='wrong-test-package':self.rows[0]['Package']='unapproved'
   if change=='missing-package':self.rows[-1].pop('Package')
   if change=='wrong-package':self.rows[-1]['Package']='unapproved'
   if change=='extra-pass-package':self.rows.append({'Action':'pass','Package':r.PACKAGE})
   if change=='extra-skip-package':self.rows.append({'Action':'skip','Package':r.PACKAGE})
   if change=='duplicate-package':self.rows.append(self.rows[-1])
   if change=='non-event':self.rows.insert(0,{})
   with self.subTest(change=change),self.assertRaises(AssertionError):self.check()
 def test_non_json_rejected(self):
  self.log.write_text('not json\n')
  with self.assertRaises(ValueError):r.verify_before(self.log)

if __name__=='__main__':unittest.main()
