import importlib.util,json,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('driver',Path(__file__).with_name('run_before.py'));d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
class Controls(unittest.TestCase):
 def rows(self):return [{'Action':'pass','Package':d.PACKAGE,'Test':name} for name in sorted(d.EXPECTED)]+[{'Action':'pass','Package':d.PACKAGE}]
 def check(self,rows,good=False):
  with tempfile.TemporaryDirectory() as folder:
   path=Path(folder)/'events.jsonl';path.write_text('\n'.join(json.dumps(row) for row in rows)+'\n')
   if good:return d.verify_before(path)
   with self.assertRaises((AssertionError,ValueError,TypeError)):d.verify_before(path)
 def test_positive_exact_inventory(self):self.assertEqual(self.check(self.rows(),True)['all_named_passes'],86)
 def test_missing_extra_duplicate(self):
  rows=self.rows()
  for bad in [rows[1:],rows+[rows[0]],rows+[{'Action':'pass','Package':d.PACKAGE,'Test':'Other'}]]:self.check(bad)
 def test_skip_failure(self):
  for action in ['skip','fail']:
   rows=self.rows();rows[0]['Action']=action;self.check(rows)
 def test_package_identity(self):
  for value in [None,'other/package']:
   rows=self.rows();rows[0]['Package']=value;self.check(rows)
 def test_package_terminal(self):
  for action in ['skip','fail']:
   rows=self.rows();rows[-1]['Action']=action;self.check(rows)
  self.check(self.rows()+[{'Action':'pass','Package':d.PACKAGE}])
 def test_package_level_race_build_panic_setup_cleanup(self):
  for message in ['DATA RACE','panic: fault','setup fault','cleanup fault','test timed out']:
   self.check(self.rows()+[{'Action':'output','Package':d.PACKAGE,'Output':message}])
  self.check(self.rows()+[{'Action':'build-fail','Package':d.PACKAGE}])
 def test_non_event(self):self.check(self.rows()+[{}])
 def test_non_json(self):
  with tempfile.TemporaryDirectory() as folder:
   path=Path(folder)/'events.jsonl';path.write_text('not JSON\n')
   with self.assertRaises(ValueError):d.verify_before(path)
 def capacity(self):return dict(total_kib=100*1024*1024,used_kib=30*1024*1024,available_kib=70*1024*1024,available_gib=70,free_percent=70,minimum_free_gib=20,minimum_free_percent=20,meets_minimum=True)
 def test_capacity_positive(self):d.verify_guard(json.dumps(self.capacity()),0)
 def test_capacity_malformed_relaxed_boolean(self):
  for key,value in [('minimum_free_gib',10),('minimum_free_percent',19),('available_kib',True),('available_gib',float('inf')),('meets_minimum',False),('available_gib',69),('free_percent',19)]:
   row=self.capacity();row[key]=value
   with self.assertRaises(AssertionError):d.verify_guard(json.dumps(row),0)
 def test_capacity_exit_and_non_json(self):
  with self.assertRaises(AssertionError):d.verify_guard(json.dumps(self.capacity()),1)
  with self.assertRaises(ValueError):d.verify_guard('not JSON',0)
if __name__=='__main__':unittest.main()
