import importlib.util,json,tempfile,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('driver',Path(__file__).with_name('run_after.py'));driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
class Controls(unittest.TestCase):
 def log(self,rows):
  root=Path(self.temp.name);path=root/'events';path.write_text('\n'.join(json.dumps(row) for row in rows)+'\n');return path
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
 def focus(self):return [dict(Action='pass',Package=driver.PACKAGE,Test=name) for name in sorted(driver.EXPECTED)]+[dict(Action='pass',Package=driver.PACKAGE)]
 def full(self):
  names=set(driver.FULL_PARENTS)|driver.EXPECTED
  return [dict(Action='skip' if name==driver.SKIP_PARENT else 'pass',Package=driver.PACKAGE,Test=name) for name in sorted(names)]+[dict(Action='output',Package=driver.PACKAGE,Test=driver.SKIP_PARENT,Output=driver.SKIP_REASON),dict(Action='pass',Package=driver.PACKAGE)]
 def test_exact_focus(self):self.assertEqual(driver.verify_focus(self.log(self.focus()))['all_named_passes'],95)
 def test_exact_full_owned_skip(self):self.assertEqual(driver.verify_full(self.log(self.full()))['parent_passes'],453)
 def test_missing_extra_duplicate(self):
  rows=self.focus()
  for changed in (rows[1:],rows+[rows[0]],rows+[dict(Action='pass',Package=driver.PACKAGE,Test='TestNew')]):
   with self.subTest(rows=len(changed)),self.assertRaises(AssertionError):driver.verify_focus(self.log(changed))
 def test_runtime_build_package_faults(self):
  for changed in (dict(Action='build-fail',Package=driver.PACKAGE),dict(Action='output',Package=driver.PACKAGE,Output='DATA RACE'),dict(Action='output',Package='wrong'),dict(Action='skip',Package=driver.PACKAGE)):
   with self.subTest(changed=changed),self.assertRaises(AssertionError):driver.verify_focus(self.log(self.focus()+[changed]))
 def test_wrong_skip_reason(self):
  rows=[row for row in self.full() if row['Action']!='output']
  with self.assertRaises(AssertionError):driver.verify_full(self.log(rows))
 def test_extra_skip_or_missing_parent(self):
  rows=self.full()
  for changed in ([row for row in rows if row.get('Test')!=driver.FULL_PARENTS[0]], [dict(row,Action='skip') if row.get('Test')==driver.FULL_PARENTS[0] else row for row in rows]):
   with self.assertRaises(AssertionError):driver.verify_full(self.log(changed))
 def test_malformed_event(self):
  path=self.log(self.focus());path.write_text(path.read_text()+'{}\n')
  with self.assertRaises(AssertionError):driver.verify_focus(path)
if __name__=='__main__':unittest.main()
