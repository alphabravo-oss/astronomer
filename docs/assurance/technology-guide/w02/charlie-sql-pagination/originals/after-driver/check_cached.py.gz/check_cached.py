"""Canonical inventory checks using only exact cached analyzers; no Go fallback."""
import hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
kind=sys.argv[1];root=Path(sys.argv[2]).resolve();assert kind in ('json','sql')
TOOLS={
 'json':('/root/.cache/go-build/7c/7cf966d9f1c4495df190ca35356460cb891b57a7e85d3011df0d3ee0e3c17d85-d/json-governance','7cf966d9f1c4495df190ca35356460cb891b57a7e85d3011df0d3ee0e3c17d85'),
 'sql':('/root/.cache/go-build/9a/9a0dae6eddd8d1cd01ca6466bc7981b2f24dd2fc5807b7b4af5eaab4c28d4492-d/sql-governance','9a0dae6eddd8d1cd01ca6466bc7981b2f24dd2fc5807b7b4af5eaab4c28d4492')}
path,digest=TOOLS[kind];tool=Path(path);assert hashlib.sha256(tool.read_bytes()).hexdigest()==digest,'cached analyzer identity drift'
spec=importlib.util.spec_from_file_location('canonical_gate',root/'scripts'/('check-'+kind+'-governance.py'));gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
def inventory(target=root):
 raw=subprocess.check_output([str(tool),str(target)],cwd=root,text=True,timeout=45)
 if kind=='sql':assert hashlib.sha256(raw.encode()).hexdigest()=='22834a1972261b45e12ac644eb8b48843118ece475765a9004fedc0c442139e2','frozen coupled SQL inventory drift'
 return json.loads(raw)
if kind=='sql':gate.inventory=inventory
else:
 original=subprocess.check_output
 def cached(command,*args,**kwargs):
  assert command==['go','run','./tools/json-governance'],'unexpected subprocess in cached JSON gate'
  return original([str(tool),str(root)],cwd=root,text=True,timeout=45)
 gate.subprocess.check_output=cached
try:gate.main()
except ValueError as error:
 print(kind+'-governance: '+str(error),file=sys.stderr);raise SystemExit(1)
