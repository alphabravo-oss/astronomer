"""Unlaunched before-only proposal using the reviewed held-leader runner."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path('/root/astronomer-all/astronomer-032-w02-charlie-pagination')
SOURCE='a1799b7828319305fa55ba87ebb038b6da6db237'
REVIEWED=Path('/tmp/w07-after-query-ee2c52d8/run_after.py')
assert hashlib.sha256(REVIEWED.read_bytes()).hexdigest()=='4b1037ee327b96de13338c5ab8ba1366e5a6bec007f0c8cf634faf50dfaace46'
spec=importlib.util.spec_from_file_location('reviewed_after',REVIEWED);after=importlib.util.module_from_spec(spec);spec.loader.exec_module(after)
after.ROOT=ROOT
PARENTS=('TestCapabilitySQLPagePreservesValidatedQueriesAndMetadata','TestCapabilityPaginationSchemaRejectsUnsupportedNumericBounds','TestCapabilitySQLPaginationFamiliesPreserveQueryScopeAndMetadata','TestCapabilitySQLPaginationSchemasKeepAllExistingBounds')
PACKAGE='github.com/alphabravocompany/astronomer-go/internal/charlie'
CAPABILITIES=('astronomer.delivery.sources','astronomer.delivery.bundles','astronomer.delivery.bundle_get','astronomer.delivery.targets','astronomer.delivery.rollouts','astronomer.delivery.deployments','astronomer.catalog.repositories','astronomer.alert.list','astronomer.audit.search','astronomer.cluster_agents.list','astronomer.task_outbox.list','astronomer.controllers.alerts','astronomer.catalog.operations','astronomer.tools.operations','astronomer.monitoring.operations','astronomer.logging.operations','astronomer.workloads.operations')
EXPECTED=set(PARENTS)
EXPECTED.update(PARENTS[0]+'/'+name for name in ('default','first','middle','maximum','default-size','default-page'))
EXPECTED.update(PARENTS[1]+'/'+name for name in ('zero-page','negative-page','oversized-page','overflow-page','zero-size','negative-size','oversized-size','overflow-size'))
EXPECTED.update(PARENTS[2]+'/'+name for name in CAPABILITIES)
EXPECTED.update(PARENTS[2]+'/'+name+'/'+mode for name in CAPABILITIES for mode in ('default','maximum'))
EXPECTED.update(PARENTS[3]+'/'+name for name in CAPABILITIES)
assert len(EXPECTED)==86

PARENTS=PARENTS+('TestCapabilitySQLPageRejectsInvalidDirectAdapterArgumentsBeforeQuery',)
EXPECTED.add(PARENTS[-1])
EXPECTED.update(PARENTS[-1]+'/'+edge for edge in ('zero-page','negative-page','oversized-page','overflow-page','zero-size','negative-size','oversized-size','overflow-size'))
assert len(EXPECTED)==95
DIRECTORY=Path(__file__).resolve().parent
FULL_PARENTS=tuple(json.loads((DIRECTORY/'full-parents.json').read_text()))
SKIP_PARENT='TestAdminVisibilityQueriesAgainstMigratedPostgres'
SKIP_REASON='CHARLIE_VISIBILITY_TEST_DATABASE_URL is not set'
FUZZ_PARENTS=('FuzzCharlieAuditEncoderNeverAdmitsCallerCanary', 'FuzzCharlieOperationalSerializerNeverEmitsCallerCanary')
FUZZ_EXPECTED=set(FUZZ_PARENTS)|{name+'/seed#'+str(i) for name in FUZZ_PARENTS for i in range(4)}

def read_events(log, full=False):
    rows=[]
    for line in log.read_text().splitlines():
        row=json.loads(line)
        assert isinstance(row,dict) and row.get('Action') in {'start','run','pause','cont','output','pass','fail','skip','build-output','build-fail'},'non-event output'
        assert row['Action']!='build-fail' and row.get('Package')==PACKAGE,'build/package drift'
        message=row.get('Output','')
        assert isinstance(message,str) and not any(marker in message for marker in ('DATA RACE','panic:','test timed out','setup failed','setup failure','cleanup failed','cleanup failure')),'runtime/setup/cleanup fault'
        rows.append(row)
    events=[row for row in rows if row['Action'] in ('pass','fail','skip') and row.get('Test')]
    assert events and len(events)==len({row['Test'] for row in events}),'missing or duplicate terminals'
    for row in events:
        assert row['Action']=='pass' or (full and row['Test']==SKIP_PARENT and row['Action']=='skip'),'unexpected failure/skip'
    package=[row for row in rows if row['Action'] in ('pass','fail','skip') and not row.get('Test')]
    assert len(package)==1 and package[0]['Action']=='pass','package terminal drift'
    if full:
        skips=[row for row in events if row['Action']=='skip']
        assert len(skips)==1 and skips[0]['Test']==SKIP_PARENT,'owned database skip inventory drift'
        assert any(row.get('Test')==SKIP_PARENT and SKIP_REASON in row.get('Output','') for row in rows),'owned database skip reason absent'
    return events

def verify_focus(log):
    events=read_events(log)
    assert len(events)==95 and {row['Test'] for row in events}==EXPECTED,'focused inventory drift'
    return {'parent_passes':5,'subcase_passes':90,'all_named_passes':95,'skips':0,'package_passes':1}

def verify_full(log):
    events=read_events(log,True)
    parents=[row for row in events if '/' not in row['Test']]
    assert len(parents)==len(FULL_PARENTS)==456 and {row['Test'] for row in parents}==set(FULL_PARENTS),'full parent inventory drift'
    assert all(row['Test'].split('/')[0] in FULL_PARENTS for row in events),'unapproved full-suite parent'
    assert EXPECTED<={row['Test'] for row in events},'focused inventory missing from full suite'
    fuzz_names={name for name in (row['Test'] for row in events) if name.startswith('Fuzz')}
    assert fuzz_names==FUZZ_EXPECTED,'fuzz seed inventory drift'
    return {'parent_passes':455,'parent_skips':1,'all_named_passes':len(events)-1,'observed_subcase_passes':len(events)-456,'package_passes':1,'skip_names':[SKIP_PARENT],'skip_reasons':[SKIP_REASON]}

ORIGINAL=Path('/tmp/w02-charlie-sql-pagination-after-a1799b78-run1')
ORIGINAL_SOURCE={'schema_version':2,'source_file_count':8313,'source_tree_sha256':'2e2ffc4e95a53399afda662008d106caf32fd7c4ba5a51d2b995933fcaed3bcd'}
ORIGINAL_HASHES={'receipt.json':'968568ec8a80b6be2a5fbeab8a7fb429ba3465f13a9a5c2ff46dc20da59a64fb','go-version.log':'ed4307d760c597256afdc696a61d47d13e832615d7741ead11c64966a440b376','focused-race.log':'9e42e5d52c2d48a59a0762787cb71827f89168d76c55c7a4992fe52c5941d153','full-race.log':'eee20486ab8090ea5bb5e8eeb771ca3bfcdadfafcc6588dfd64431fb16fe581b'}

def reparse_original(directory=ORIGINAL):
    for name,digest in ORIGINAL_HASHES.items():
        path=directory/name
        assert not path.is_symlink() and path.is_file() and path.stat().st_size<=32*1024*1024,'original bounded regular evidence required'
        assert hashlib.sha256(path.read_bytes()).hexdigest()==digest,'original evidence drift'
    original=json.loads((directory/'receipt.json').read_text())
    assert original['source']==SOURCE and original.get('failure_category')=='AssertionError','original receipt identity/failure drift'
    assert original['source_before']==original['source_after']==ORIGINAL_SOURCE and original['source_stable'] and original['runner_final_guard_pass'],'original source/guard drift'
    assert original['go_before']==original['go_after']==GO_IDENTITY,'original Go identity drift'
    assert [step['name'] for step in original['steps']]==['go-version','focused-race','full-race'],'original command inventory drift'
    for step in original['steps']:
        outcome=step['outcome']
        assert step['source_before']==step['source_after']==ORIGINAL_SOURCE and step['source_stable'] and step['final_guard_pass'],'original step source/guard fault'
        assert outcome['exitCode']==0 and outcome['drained'] and outcome['leaderHeldUntilDrain'] and not outcome['reason'] and not outcome['liveDescendantsAfterDrain'],'original child fault'
        assert step['log_sha256']==ORIGINAL_HASHES[step['name']+'.log'],'original recorded raw hash drift'
    assert (directory/'go-version.log').read_text().strip()=='go version go1.27.2 linux/amd64'
    return {'original_receipt_sha256':ORIGINAL_HASHES['receipt.json'],'original_full_raw_sha256':ORIGINAL_HASHES['full-race.log'],'focused':verify_focus(directory/'focused-race.log'),'full':verify_full(directory/'full-race.log'),'fuzz_seed_names':sorted(FUZZ_EXPECTED),'source':ORIGINAL_SOURCE,'scope':'Independent immutable byte replay; original rejected receipt remains unchanged, no new runtime execution'}

def verify_guard(output,exit_code):
    assert exit_code==0 and isinstance(output,str) and len(output)<=4096,'fatal capacity guard'
    row=json.loads(output)
    assert isinstance(row,dict),'malformed capacity object'
    fields=('total_kib','used_kib','available_kib','available_gib','free_percent','minimum_free_gib','minimum_free_percent')
    assert all(type(row.get(key)) is int and 0<=row[key]<(1<<63) for key in fields),'nonfinite/noninteger capacity field'
    assert row['minimum_free_gib']==20 and row['minimum_free_percent']==20,'default guard thresholds changed'
    assert row.get('meets_minimum') is True,'capacity minimum not met'
    assert row['total_kib']>0 and row['used_kib']<=row['total_kib'] and row['available_kib']<=row['total_kib'],'inconsistent capacity bounds'
    assert row['available_gib']==row['available_kib']//(1024*1024),'inconsistent available GiB'
    assert row['available_kib']>=20*1024*1024 and 20<=row['free_percent']<=100,'insufficient default headroom'
    return row

NODE='/root/.cache/astronomer-032/toolchains/node-v26.11.1-linux-x64/bin/node'
WRAPPER_SHA='6046b93ac5a9d0ad2a3e0c81d2b030a4615732432e79da850d687de7b05885db'

GO_IDENTITY={'path': '/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.linux-amd64/bin/go', 'sha256': '548d3c32f83fa81152f543eb1526be7884cfe0526eb5e9ce29d3eca14786e7e0', 'device': 2049, 'inode': 2360704, 'size': 17164055, 'mtime_ns': 1791570925918518586}
GO=Path(GO_IDENTITY['path'])
def go_identity():
    assert not GO.is_symlink(), 'selected Go binary symlink drift'
    stat=GO.stat()
    return {'path':str(GO),'sha256':hashlib.sha256(GO.read_bytes()).hexdigest(),'device':stat.st_dev,'inode':stat.st_ino,'size':stat.st_size,'mtime_ns':stat.st_mtime_ns}

def assert_go_identity():
    assert go_identity()==GO_IDENTITY, 'selected Go binary identity drift'

def interrupt(_number,_frame):
    for number in (signal.SIGTERM,signal.SIGINT):signal.signal(number,signal.SIG_IGN)
    raise RuntimeError('owned lane interrupted')

def step_timeout(name,deadline):
    remaining=deadline-time.monotonic()
    assert remaining>0, 'overall owned lane deadline'
    return min(30 if name=='go-version' else (600 if name in ('focused-race','full-race','vet') else 60),remaining)

def main():
    assert len(sys.argv)==2
    output=Path(sys.argv[1]);os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve()),'receipt must be outside source'
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    deadline=time.monotonic()+1000
    source=subprocess.check_output(['git','rev-parse',SOURCE],cwd=ROOT,timeout=10).decode().strip()
    receipt={'source':source,'steps':[],'scope':'Supplement only: immutable original focused95/full456 Test+Fuzz reparse, followed by unlaunched vet/static gates; original failed receipt unchanged, one owned PostgreSQL skip'}
    def guard(stage):
        check=subprocess.run(['bash','scripts/check-build-capacity.sh','--min-free-gib','20','--min-free-percent','20','--json'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15)
        with (output/'capacity.jsonl').open('a') as stream:stream.write(json.dumps({'stage':stage,'time':time.time(),'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr})+'\n')
        verify_guard(check.stdout,check.returncode)
    def ownership():
        assert_go_identity()
        binding_path=Path(__file__).with_name('source-bindings.json')
        assert hashlib.sha256(binding_path.read_bytes()).hexdigest()=='3d313a6c59d153a1fd73b0af3d72569423b7e3693b64e323a260c696ea8e1997','source binding manifest drift'
        for row in json.loads(binding_path.read_text()):
            path=Path(row['path']);assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'bound source/tool drift'
            if 'inode' in row:
                stat=path.stat();assert (stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns)==(row['device'],row['inode'],row['size'],row['mtime_ns']),'bound tool inode drift'
        assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,timeout=10)==b''
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,timeout=10).decode().strip()==source
    handlers={number:signal.signal(number,interrupt) for number in (signal.SIGTERM,signal.SIGINT)}
    try:
        guard('initial');ownership();receipt['go_before']=go_identity();receipt['source_before']=after.fences.fingerprint(ROOT)
        assert receipt['source_before']==ORIGINAL_SOURCE,'current source differs from original runtime freeze'
        receipt['original_replay']=reparse_original()
        env=dict(os.environ,GOTOOLCHAIN='go1.27.2',GOWORK='off',GOMAXPROCS='4',GOFLAGS='-p=2 -mod=readonly',GOFIPS140='off')
        receipt['safe_go_environment']={name:env[name] for name in ('GOTOOLCHAIN','GOWORK','GOMAXPROCS','GOFLAGS','GOFIPS140')}
        env['PATH']=str(GO.parent)+':'+env['PATH']
        env.pop('CHARLIE_VISIBILITY_TEST_DATABASE_URL',None)
        wrapper=Path(__file__).with_name('check_cached.py')
        assert hashlib.sha256(wrapper.read_bytes()).hexdigest()==WRAPPER_SHA,'cached gate wrapper drift'
        commands=[('vet',[str(GO),'vet','./internal/charlie']),
          ('boundaries',[NODE,'scripts/check-dependency-boundaries.mjs']),
          ('complexity',[NODE,'scripts/check-complexity-budget.mjs']),
          ('json-governance',[sys.executable,str(wrapper),'json',str(ROOT)]),
          ('sql-governance',[sys.executable,str(wrapper),'sql',str(ROOT)])]
        for name,command in commands:
            step=after.run_step(command,command,env,output/(name+'.log'),guard,ownership,lambda:after.fences.fingerprint(ROOT),timeout=step_timeout(name,deadline))
            receipt['steps'].append({'name':name,**step})
            result=step.get('outcome') or {}
            assert step['source_stable'] and step['final_guard_pass'] and result.get('drained') and not result.get('reason'),'ownership/source/guard fault'
            if name=='go-version':
                assert after.passed(step) and (output/'go-version.log').read_text().strip()=='go version go1.27.2 linux/amd64'
            elif name=='sql-governance':
                assert result['exitCode'] in (0,1),'coupled SQL check process failure'
                if result['exitCode']==1:
                    assert 'sql-governance: SQL owner source changed: internal/delivery/provider/provider.go' in (output/(name+'.log')).read_text(),'unexpected coupled SQL diagnostic'
                receipt['coupled_sql']={'exit_code':result['exitCode'],'status':'PASS' if result['exitCode']==0 else 'FAIL','scope':'Canonical whole-source SQL gate; inherited reviewed provider/Grafana drift remains open, no acceptance or metadata refresh','actual_inventory_sha256':'22834a1972261b45e12ac644eb8b48843118ece475765a9004fedc0c442139e2'}
            else:
                assert result['exitCode']==0,'after gate failure'
                if name=='focused-race':receipt['focused_events']=verify_focus(output/(name+'.log'))
                if name=='full-race':receipt['full_events']=verify_full(output/(name+'.log'))
    except BaseException as error:receipt['failure_category']=type(error).__name__
    finally:
        try:
            receipt['go_after']=go_identity()
            assert receipt['go_after']==GO_IDENTITY and receipt.get('go_before')==GO_IDENTITY, 'selected Go binary identity drift'
            receipt['source_after']=after.fences.fingerprint(ROOT)
            receipt['source_stable']=receipt.get('source_before')==receipt['source_after']
        except BaseException as error:receipt['final_failure_category']=type(error).__name__
        try:
            guard('runner-final');receipt['runner_final_guard_pass']=True
        except BaseException as error:receipt['final_guard_failure_category']=type(error).__name__
        (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        for number,handler in handlers.items():signal.signal(number,handler)
    qualified=len(receipt['steps'])==5 and 'original_replay' in receipt and receipt.get('source_stable') and receipt.get('runner_final_guard_pass') and 'failure_category' not in receipt and 'final_failure_category' not in receipt and 'final_guard_failure_category' not in receipt
    print(json.dumps({'receipt':str(output/'receipt.json'),'charlie_scoped_qualification_complete':bool(qualified),'coupled_sql_pass':receipt.get('coupled_sql',{}).get('status')=='PASS'}))
    return 0 if qualified else 1

if __name__=='__main__':raise SystemExit(main())
