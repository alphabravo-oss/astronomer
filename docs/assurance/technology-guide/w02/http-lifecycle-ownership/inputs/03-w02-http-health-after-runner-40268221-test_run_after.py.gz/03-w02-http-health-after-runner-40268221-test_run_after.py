import importlib.util,json,tempfile,unittest
from pathlib import Path
from unittest import mock
s=importlib.util.spec_from_file_location('runner',Path(__file__).with_name('run_after.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)

class InventoryTest(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.log=Path(self.temp.name)/'events.log'
  self.rows=[{'Action':'pass','Test':name,'Package':r.EXPECTED[name]} for name in sorted(r.EXPECTED)]+[{'Action':'pass','Package':package} for package in sorted(r.EXPECTED_PACKAGES)]
 def check(self):
  self.log.write_text(''.join(json.dumps(row)+'\n' for row in self.rows));return r.verify_after(self.log)
 def test_exact_inventory(self):self.assertEqual(self.check(),{'parent_passes':8,'leaf_passes':0,'skips':0,'package_passes':3})
 def test_missing_duplicate_extra_pass_and_skip_rejected(self):
  original=list(self.rows)
  for change in ['missing','duplicate','extra','fail','skip','package']:
   self.rows=[dict(row) for row in original]
   if change=='missing':self.rows.pop(0)
   if change=='duplicate':self.rows.append(self.rows[0])
   if change=='extra':self.rows[0]['Test']='unapproved'
   if change in ('fail','skip'):self.rows[0]['Action']=change
   if change=='package':self.rows.pop()
   with self.subTest(change=change),self.assertRaises(AssertionError):self.check()
 def test_missing_wrong_package_and_contradictory_terminals(self):
  original=list(self.rows)
  for change in ['missing-test-package','wrong-test-package','missing-package','wrong-package','extra-pass-package','extra-skip-package','duplicate-package','non-event']:
   self.rows=[dict(row) for row in original]
   if change=='missing-test-package':self.rows[0].pop('Package')
   if change=='wrong-test-package':self.rows[0]['Package']='unapproved'
   if change=='missing-package':self.rows[-1].pop('Package')
   if change=='wrong-package':self.rows[-1]['Package']='unapproved'
   if change=='extra-pass-package':self.rows.append({'Action':'pass','Package':sorted(r.EXPECTED_PACKAGES)[0]})
   if change=='extra-skip-package':self.rows.append({'Action':'skip','Package':sorted(r.EXPECTED_PACKAGES)[0]})
   if change=='duplicate-package':self.rows.append(self.rows[-1])
   if change=='non-event':self.rows.insert(0,{})
   with self.subTest(change=change),self.assertRaises(AssertionError):self.check()
 def test_non_json_rejected(self):
  self.log.write_text('not json\n')
  with self.assertRaises(ValueError):r.verify_after(self.log)


class OwnershipTest(unittest.TestCase):
 def test_changed_binary_bytes_or_inode_rejected(self):
  for field in ['sha256','inode','device','mtime_ns','size']:
   changed=dict(r.GO_IDENTITY);changed[field]='drift'
   with self.subTest(field=field),mock.patch.object(r,'go_identity',return_value=changed),self.assertRaises(AssertionError):r.assert_go_identity()
  with mock.patch.object(r,'go_identity',return_value=dict(r.GO_IDENTITY)):r.assert_go_identity()
 def test_version_and_overall_deadlines_remain_finite(self):
  with mock.patch.object(r.time,'monotonic',return_value=10):
   self.assertEqual(r.step_timeout('go-version',100),30)
   self.assertEqual(r.step_timeout('race',1000),600)
   self.assertEqual(r.step_timeout('race',15),5)
   with self.assertRaises(AssertionError):r.step_timeout('race',10)
 def test_first_interrupt_masks_both_repeated_signals(self):
  with mock.patch.object(r.signal,'signal') as signals:
   with self.assertRaises(RuntimeError):r.interrupt(r.signal.SIGINT,None)
   self.assertEqual(signals.call_args_list,[mock.call(r.signal.SIGTERM,r.signal.SIG_IGN),mock.call(r.signal.SIGINT,r.signal.SIG_IGN)])

if __name__=='__main__':unittest.main()
