"""Unlaunched after-only proposal using the reviewed held-leader runner."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path('/root/astronomer-all/astronomer-032-w02-history-policy')
SOURCE='6ee57e2d'
REVIEWED=Path('/tmp/w07-after-query-ee2c52d8/run_after.py')
assert hashlib.sha256(REVIEWED.read_bytes()).hexdigest()=='4b1037ee327b96de13338c5ab8ba1366e5a6bec007f0c8cf634faf50dfaace46'
spec=importlib.util.spec_from_file_location('reviewed_after',REVIEWED);after=importlib.util.module_from_spec(spec);spec.loader.exec_module(after)
after.ROOT=ROOT
PARENTS=('TestCheckedOutboxSQLWindowMatchesLegacyMetadata','TestCheckedInstalledSQLWindowMatchesLegacyMetadataAndScopes')
PACKAGE='github.com/alphabravocompany/astronomer-go/internal/handler'
CASES=('default','normal','zero','negative','negative-overflow','malformed','limit-overflow','upper-window','offset-rejected','offset-repeated','offset-overflow','cursor-rejected')
EXPECTED={parent:'pass' for parent in PARENTS}
for parent,branches in zip(PARENTS,(('list','dead'),('all','scoped'))):
    for branch in branches:
        EXPECTED[parent+'/'+branch]='pass'
        EXPECTED.update({parent+'/'+branch+'/'+case:'pass' for case in CASES})

NODE='/root/.cache/astronomer-032/toolchains/node-v26.11.1-linux-x64/bin/node'
JSON_TOOL=Path('/root/.cache/go-build/7c/7cf966d9f1c4495df190ca35356460cb891b57a7e85d3011df0d3ee0e3c17d85-d/json-governance')
JSON_SHA='7cf966d9f1c4495df190ca35356460cb891b57a7e85d3011df0d3ee0e3c17d85'
WRAPPER_SHA='6aa91bfd9f70ee40a8f8750aff0a7af0b56d58273816b49ba852b7f18335d6c6'

def verify_after(log):
    rows=[]
    for line in log.read_text().splitlines():
        row=json.loads(line)
        assert isinstance(row,dict) and row.get('Action') in {'start','run','pause','cont','output','pass','fail','skip','build-output','build-fail'},'non-event output'
        rows.append(row)
    events=[row for row in rows if row['Action'] in ('pass','fail','skip') and row.get('Test')]
    assert len(events)==len(EXPECTED) and {row['Test'] for row in events}==set(EXPECTED),'unexpected named inventory'
    assert all(row['Action']=='pass' and row.get('Package')==PACKAGE for row in events),'after package or outcome drift'
    package=[row for row in rows if row['Action'] in ('pass','fail','skip') and not row.get('Test')]
    assert len(package)==1 and package[0]['Action']=='pass' and package[0].get('Package')==PACKAGE,'package terminal drift'
    return {'parent_passes':2,'branch_passes':4,'leaf_passes':48,'skips':0,'package_passes':1}

GO_IDENTITY={'path': '/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.linux-amd64/bin/go', 'sha256': '548d3c32f83fa81152f543eb1526be7884cfe0526eb5e9ce29d3eca14786e7e0', 'device': 2049, 'inode': 2360704, 'size': 17164055, 'mtime_ns': 1791570925918518586}
GO=Path(GO_IDENTITY['path'])
def go_identity():
    assert not GO.is_symlink(), 'selected Go binary symlink drift'
    stat=GO.stat()
    return {'path':str(GO),'sha256':hashlib.sha256(GO.read_bytes()).hexdigest(),'device':stat.st_dev,'inode':stat.st_ino,'size':stat.st_size,'mtime_ns':stat.st_mtime_ns}

def assert_go_identity():
    assert go_identity()==GO_IDENTITY, 'selected Go binary identity drift'

def interrupt(_number,_frame):
    for number in (signal.SIGTERM,signal.SIGINT):signal.signal(number,signal.SIG_IGN)
    raise RuntimeError('owned lane interrupted')

def step_timeout(name,deadline):
    remaining=deadline-time.monotonic()
    assert remaining>0, 'overall owned lane deadline'
    return min(30 if name=='go-version' else 600,remaining)

def main():
    assert len(sys.argv)==2
    output=Path(sys.argv[1]);os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve()),'receipt must be outside source'
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    deadline=time.monotonic()+1800
    source=subprocess.check_output(['git','rev-parse',SOURCE],cwd=ROOT,timeout=10).decode().strip()
    receipt={'source':source,'steps':[],'scope':'checked SQL pagination refactor after characterization: exact two parents/four branches/48 leaves under race plus handler vet and canonical source gates; no database mutation'}
    def guard(stage):
        check=subprocess.run(['bash','scripts/check-build-capacity.sh','--json'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15)
        with (output/'capacity.jsonl').open('a') as stream:stream.write(json.dumps({'stage':stage,'time':time.time(),'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr})+'\n')
        assert check.returncode==0,'fatal capacity guard'
    def ownership():
        assert_go_identity()
        assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,timeout=10)==b''
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,timeout=10).decode().strip()==source
    handlers={number:signal.signal(number,interrupt) for number in (signal.SIGTERM,signal.SIGINT)}
    try:
        guard('initial');ownership();receipt['go_before']=go_identity();receipt['source_before']=after.fences.fingerprint(ROOT)
        env=dict(os.environ,GOTOOLCHAIN='go1.27.2',GOWORK='off',GOMAXPROCS='4',GOFLAGS='-p=2')
        env['PATH']=str(GO.parent)+':'+env['PATH']
        assert hashlib.sha256(JSON_TOOL.read_bytes()).hexdigest()==JSON_SHA,'cached JSON checker drift'
        receipt['cached_json_checker_sha256']=JSON_SHA
        wrapper=Path(__file__).with_name('check_json_cached.py')
        assert hashlib.sha256(wrapper.read_bytes()).hexdigest()==WRAPPER_SHA,'cached wrapper drift'
        commands=[('go-version',[str(GO),'version']),('after',[str(GO),'test','-race','-json','-count=1','-run','^('+'|'.join(PARENTS)+')$','./internal/handler']),('vet',[str(GO),'vet','./internal/handler']),('json-governance',[sys.executable,str(wrapper)]),('boundaries',[NODE,'scripts/check-dependency-boundaries.mjs']),('complexity',[NODE,'scripts/check-complexity-budget.mjs'])]
        for name,command in commands:
            step=after.run_step(command,command,env,output/(name+'.log'),guard,ownership,lambda:after.fences.fingerprint(ROOT),timeout=step_timeout(name,deadline))
            receipt['steps'].append({'name':name,**step})
            assert after.passed(step),'after check failed or ownership/source/guard fault'
            if name=='go-version':
                assert (output/'go-version.log').read_text().strip()=='go version go1.27.2 linux/amd64'
            elif name=='after':receipt['events']=verify_after(output/'after.log')
    except BaseException as error:receipt['failure_category']=type(error).__name__
    finally:
        try:
            receipt['go_after']=go_identity()
            assert receipt['go_after']==GO_IDENTITY and receipt.get('go_before')==GO_IDENTITY, 'selected Go binary identity drift'
            receipt['source_after']=after.fences.fingerprint(ROOT)
            receipt['source_stable']=receipt.get('source_before')==receipt['source_after']
            guard('runner-final');receipt['runner_final_guard_pass']=True
        except BaseException as error:receipt['final_failure_category']=type(error).__name__
        (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        for number,handler in handlers.items():signal.signal(number,handler)
    qualified=len(receipt['steps'])==6 and 'events' in receipt and receipt.get('source_stable') and receipt.get('runner_final_guard_pass') and 'failure_category' not in receipt and 'final_failure_category' not in receipt
    print(json.dumps({'receipt':str(output/'receipt.json'),'after_qualified':bool(qualified)}))
    return 0 if qualified else 1

if __name__=='__main__':raise SystemExit(main())
