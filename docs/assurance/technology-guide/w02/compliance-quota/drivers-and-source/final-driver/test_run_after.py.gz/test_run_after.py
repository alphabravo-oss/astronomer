import importlib.util,json,tempfile,unittest
from pathlib import Path
s=importlib.util.spec_from_file_location('quota_after',Path(__file__).with_name('run_after.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
class InventoryTest(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.log=Path(self.temp.name)/'events.log'
 def rows(self,names):return [{'Action':'pass','Package':r.PACKAGE,'Test':name} for name in sorted(names)]+[{'Action':'pass','Package':r.PACKAGE}]
 def check(self,rows,full=False):
  self.log.write_text(''.join(json.dumps(row)+'\n' for row in rows));return (r.verify_full if full else r.verify_focus)(self.log)
 def test_exact_focus50_and_full68(self):
  self.assertEqual(self.check(self.rows(r.EXPECTED)),{'parent_passes':2,'leaf_passes':48,'skips':0,'package_passes':1})
  self.assertEqual(self.check(self.rows(r.FULL_EXPECTED),True),{'parent_passes':20,'all_named_passes':68,'all_observed_subcase_passes':48,'skips':0,'package_passes':1})
 def test_missing_duplicate_extra_focus_and_full(self):
  for full,names in ((False,r.EXPECTED),(True,r.FULL_EXPECTED)):
   for change in ('missing','duplicate','extra'):
    rows=self.rows(names)
    if change=='missing':rows.pop(0)
    if change=='duplicate':rows.append(rows[0])
    if change=='extra':rows[0]['Test']='unapproved'
    with self.subTest(full=full,change=change),self.assertRaises(AssertionError):self.check(rows,full)
 def test_any_fail_or_skip_rejected(self):
  for action in ('fail','skip'):
   rows=self.rows(r.EXPECTED);rows[0]['Action']=action
   with self.subTest(action=action),self.assertRaises(AssertionError):self.check(rows)
 def test_wrong_or_missing_package(self):
  for index in (0,-1):
   for wrong in (None,'unapproved'):
    rows=self.rows(r.EXPECTED)
    if wrong is None:rows[index].pop('Package')
    else:rows[index]['Package']=wrong
    with self.subTest(index=index,wrong=wrong),self.assertRaises(AssertionError):self.check(rows)
 def test_package_fail_skip_duplicate_or_missing(self):
  for change in ('fail','skip','duplicate','missing'):
   rows=self.rows(r.EXPECTED)
   if change in ('fail','skip'):rows[-1]['Action']=change
   if change=='duplicate':rows.append(rows[-1])
   if change=='missing':rows.pop()
   with self.subTest(change=change),self.assertRaises(AssertionError):self.check(rows)
 def test_global_race_panic_setup_cleanup_and_build_failure(self):
  for row in ({'Action':'build-fail','Package':r.PACKAGE},*({'Action':'output','Package':r.PACKAGE,'Output':m} for m in ('DATA RACE','panic: fixture','setup failed','cleanup failed'))):
   with self.subTest(row=row),self.assertRaises(AssertionError):self.check(self.rows(r.EXPECTED)+[row])
 def test_non_event_and_non_json(self):
  with self.assertRaises(AssertionError):self.check([{}]+self.rows(r.EXPECTED))
  self.log.write_text('not json\n')
  with self.assertRaises(ValueError):r.verify_focus(self.log)
 def test_numeric_default_capacity_guards(self):
  good={'total_kib':100*1024*1024,'used_kib':60*1024*1024,'available_kib':40*1024*1024,'available_gib':40,'free_percent':40,'minimum_free_gib':20,'minimum_free_percent':20,'meets_minimum':True}
  self.assertEqual(r.verify_guard(json.dumps(good),0),good)
  for change in ({'minimum_free_gib':0},{'minimum_free_percent':0},{'available_kib':True},{'available_kib':float('inf')},{'available_gib':39},{'free_percent':19},{'meets_minimum':1},{'meets_minimum':False}):
   with self.subTest(change=change),self.assertRaises(AssertionError):r.verify_guard(json.dumps(good|change),0)
 def test_finite_stage_and_overall_timeouts(self):
  with self.assertRaises(AssertionError):r.step_timeout('full-race',0)
  for stage,cap in (('go-version',30),('focused-race',600),('full-race',600),('vet',600),('sql-governance',60)):
   self.assertLessEqual(r.step_timeout(stage,r.time.monotonic()+3000),cap)
if __name__=='__main__':unittest.main()
