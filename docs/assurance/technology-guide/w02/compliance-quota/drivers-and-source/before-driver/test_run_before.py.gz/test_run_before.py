import importlib.util,json,tempfile,unittest
from pathlib import Path
s=importlib.util.spec_from_file_location('quota_before',Path(__file__).with_name('run_before.py'));r=importlib.util.module_from_spec(s);s.loader.exec_module(r)

class InventoryTest(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.log=Path(self.temp.name)/'events.log'
  self.rows=[]
  for name,action in sorted(r.EXPECTED.items()):
   if action=='fail' and name!=r.PARENTS[0]:self.rows.append({'Action':'output','Test':name,'Package':r.PACKAGE,'Output':r.DIAGNOSTIC+'\n'})
   self.rows.append({'Action':action,'Test':name,'Package':r.PACKAGE})
  self.rows.append({'Action':'fail','Package':r.PACKAGE})
 def check(self):
  self.log.write_text(''.join(json.dumps(row)+'\n' for row in self.rows));return r.verify_before(self.log)
 def test_exact_mixed_inventory(self):
  self.assertEqual(self.check(),{'parent_failures':1,'parent_passes':1,'leaf_failures':16,'leaf_passes':32,'skips':0,'package_failures':1})
 def test_missing_duplicate_extra_terminals(self):
  initial=[dict(row) for row in self.rows]
  for change in ('missing','duplicate','extra'):
   self.rows=[dict(row) for row in initial]
   terminal=next(row for row in self.rows if row['Action']=='fail' and row.get('Test'))
   if change=='missing':self.rows.remove(terminal)
   if change=='duplicate':self.rows.append(terminal)
   if change=='extra':terminal['Test']='unexpected'
   with self.subTest(change=change),self.assertRaises(AssertionError):self.check()
 def test_skip_and_wrong_mixed_outcomes(self):
  initial=[dict(row) for row in self.rows]
  for expected,replacement in (('fail','pass'),('pass','fail'),('fail','skip')):
   self.rows=[dict(row) for row in initial];next(row for row in self.rows if row['Action']==expected and row.get('Test'))['Action']=replacement
   with self.subTest(expected=expected,replacement=replacement),self.assertRaises(AssertionError):self.check()
 def test_missing_wrong_package(self):
  initial=[dict(row) for row in self.rows]
  for index in (-1,1):
   for wrong in (None,'unapproved'):
    self.rows=[dict(row) for row in initial]
    if wrong is None:self.rows[index].pop('Package')
    else:self.rows[index]['Package']=wrong
    with self.subTest(index=index,wrong=wrong),self.assertRaises(AssertionError):self.check()
 def test_package_duplicates_pass_and_skip(self):
  initial=[dict(row) for row in self.rows]
  for action in ('pass','fail','skip'):
   self.rows=[dict(row) for row in initial]+[{'Action':action,'Package':r.PACKAGE}]
   with self.subTest(action=action),self.assertRaises(AssertionError):self.check()
 def test_fail_names_without_boundary_diagnostic_cannot_qualify(self):
  initial=[dict(row) for row in self.rows]
  for output in ('fixture application failed','fixture snapshot failed','setup failed',''):
   self.rows=[dict(row) for row in initial];next(row for row in self.rows if row['Action']=='output')['Output']=output
   with self.subTest(output=output),self.assertRaises(AssertionError):self.check()
 def test_cleanup_fault_after_diagnostic_cannot_qualify(self):
  next(row for row in self.rows if row['Action']=='output')['Output']+='cleanup failed'
  with self.assertRaises(AssertionError):self.check()
 def test_non_event_and_non_json(self):
  self.rows.insert(0,{})
  with self.assertRaises(AssertionError):self.check()
  self.log.write_text('not json\n')
  with self.assertRaises(ValueError):r.verify_before(self.log)
 def test_package_level_faults_and_build_failure_rejected(self):
  initial=[dict(row) for row in self.rows]
  for row in ({'Action':'build-fail','Package':r.PACKAGE},*({'Action':'output','Package':r.PACKAGE,'Output':message} for message in ('WARNING: DATA RACE','panic: fixture','setup failed','cleanup failed'))):
   self.rows=[dict(item) for item in initial]+[row]
   with self.subTest(row=row),self.assertRaises(AssertionError):self.check()
 def test_numeric_default_capacity_guard(self):
  good={'total_kib':100*1024*1024,'used_kib':60*1024*1024,'available_kib':40*1024*1024,'available_gib':40,'free_percent':40,'minimum_free_gib':20,'minimum_free_percent':20,'meets_minimum':True}
  self.assertEqual(r.verify_guard(json.dumps(good),0),good)
  for change in ({'minimum_free_gib':0},{'minimum_free_percent':0},{'minimum_free_gib':21},{'available_kib':True},{'available_kib':float('inf')},{'available_gib':39},{'free_percent':19},{'available_kib':19*1024*1024,'available_gib':19},{'meets_minimum':1},{'meets_minimum':False},{'total_kib':0},{'available_kib':1<<63},{'free_percent':101}):
   with self.subTest(change=change),self.assertRaises(AssertionError):r.verify_guard(json.dumps(good|change),0)
  for payload in ('{}','[]','not json'):
   with self.subTest(payload=payload),self.assertRaises((AssertionError,ValueError)):r.verify_guard(payload,0)
  with self.assertRaises(AssertionError):r.verify_guard(json.dumps(good),1)
 def test_overall_deadline_bounds_each_stage(self):
  with self.assertRaises(AssertionError):r.step_timeout('before',0)
  self.assertLessEqual(r.step_timeout('go-version',r.time.monotonic()+1000),30)
  self.assertLessEqual(r.step_timeout('before',r.time.monotonic()+1000),600)

if __name__=='__main__':unittest.main()
