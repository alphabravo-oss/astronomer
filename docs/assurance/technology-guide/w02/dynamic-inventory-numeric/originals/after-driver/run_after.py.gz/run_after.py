"""Unlaunched before-only proposal using the reviewed held-leader runner."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path('/root/astronomer-all/astronomer-032-w02-dynamic-counts')
SOURCE='58c1b512'
REVIEWED=Path('/tmp/w07-after-query-ee2c52d8/run_after.py')
assert hashlib.sha256(REVIEWED.read_bytes()).hexdigest()=='4b1037ee327b96de13338c5ab8ba1366e5a6bec007f0c8cf634faf50dfaace46'
spec=importlib.util.spec_from_file_location('reviewed_after',REVIEWED);after=importlib.util.module_from_spec(spec);spec.loader.exec_module(after)
after.ROOT=ROOT
PARENTS = (
    'TestDynamicInventoryInvalidNumericCannotBecomeHealthy',
    'TestDynamicInventoryAggregateOverflowCannotWrapPositive',
    'TestDynamicInventoryInvalidProjectionRemainsExplicitlyUnavailable',
    'TestDynamicInventoryValidNumericProjectionPreservesValues',
)
PACKAGE = 'github.com/alphabravocompany/astronomer-go/internal/agent/delivery'
EXPECTED = {name: 'fail' for name in PARENTS[:3]} | {PARENTS[3]: 'pass'}
EXPECTED.update({PARENTS[0] + '/' + name: 'fail' for name in (
    'replica-positive-wrap', 'replica-over-max', 'replica-negative', 'replica-fractional',
    'size-overflow-string', 'size-negative', 'size-fractional', 'used-invalid-string')})
EXPECTED.update({PARENTS[1] + '/' + name: 'fail' for name in (
    'volume-bytes', 'node-disk-bytes', 'gateway-attached-routes')})
EXPECTED.update({PARENTS[3] + '/' + name: 'pass' for name in (
    'int64', 'integer-string', 'integral-float', 'wire-maximum', 'optional-missing')})

EXPECTED=set(EXPECTED)
PARENTS=PARENTS+('TestInventoryNumberRejectsNonIntegralAndUnrepresentableValues','TestInventoryCheckedSumAndNarrowing','TestLegacyDynamicInvalidNumericProjectionIsNotMissing','TestDynamicCacheRetainsBoundedBackingArraysAndAggregateCounts','TestObservedInventoryBoundsResourcesButPreservesTotal','TestNormalizedFluxInventorySatisfiesProtocol')
EXPECTED.update(PARENTS[4:])
assert len(EXPECTED)==26
DIRECTORY=Path(__file__).resolve().parent
FULL_PARENTS=tuple(json.loads((DIRECTORY/'full-parents.json').read_text()))
FUZZ_PARENTS=('FuzzValidateAssignment', 'FuzzConditionSanitization')
FUZZ_EXPECTED=set(FUZZ_PARENTS)|{name+'/seed#0' for name in FUZZ_PARENTS}

def read_events(log):
    rows=[]
    for line in log.read_text().splitlines():
        row=json.loads(line)
        assert isinstance(row,dict) and row.get('Action') in {'start','run','pause','cont','output','pass','fail','skip','build-output','build-fail'},'non-event output'
        assert row['Action']!='build-fail' and row.get('Package')==PACKAGE,'build/package drift'
        message=row.get('Output','')
        assert isinstance(message,str) and not any(marker in message for marker in ('DATA RACE','panic:','test timed out','setup failure','setup failed','cleanup failure','cleanup failed')),'runtime/setup/cleanup fault'
        rows.append(row)
    events=[row for row in rows if row['Action'] in ('pass','fail','skip') and row.get('Test')]
    assert events and len(events)==len({row['Test'] for row in events}),'missing or duplicate terminals'
    assert all(row['Action']=='pass' for row in events),'unexpected failure/skip'
    packages=[row for row in rows if row['Action'] in ('pass','fail','skip') and not row.get('Test')]
    assert len(packages)==1 and packages[0]['Action']=='pass','package terminal drift'
    return events

def verify_focus(log):
    events=read_events(log)
    assert len(events)==26 and {row['Test'] for row in events}==EXPECTED,'focused inventory drift'
    return {'parent_passes':10,'subcase_passes':16,'all_named_passes':26,'skips':0,'package_passes':1,'preserves_aggregate_300_resource_128':True}

def verify_full(log):
    events=read_events(log)
    parents=[row for row in events if '/' not in row['Test']]
    assert len(parents)==len(FULL_PARENTS) and {row['Test'] for row in parents}==set(FULL_PARENTS),'full parent inventory drift'
    assert all(row['Test'].split('/')[0] in FULL_PARENTS for row in events),'unapproved full-suite parent'
    assert EXPECTED<={row['Test'] for row in events},'focused inventory missing from full suite'
    assert {row['Test'] for row in events if row['Test'].startswith('Fuzz')}==FUZZ_EXPECTED,'fuzz seed inventory drift'
    return {'parent_passes':len(FULL_PARENTS),'all_named_passes':len(events),'observed_subcase_passes':len(events)-len(FULL_PARENTS),'skips':0,'package_passes':1}

def verify_guard(output,exit_code):
    assert exit_code==0 and isinstance(output,str) and len(output)<=4096,'fatal capacity guard'
    row=json.loads(output)
    assert isinstance(row,dict),'malformed capacity object'
    fields=('total_kib','used_kib','available_kib','available_gib','free_percent','minimum_free_gib','minimum_free_percent')
    assert all(type(row.get(key)) is int and 0<=row[key]<(1<<63) for key in fields),'nonfinite/noninteger capacity field'
    assert row['minimum_free_gib']==20 and row['minimum_free_percent']==20,'default guard thresholds changed'
    assert row.get('meets_minimum') is True,'capacity minimum not met'
    assert row['total_kib']>0 and row['used_kib']<=row['total_kib'] and row['available_kib']<=row['total_kib'],'inconsistent capacity bounds'
    assert row['available_gib']==row['available_kib']//(1024*1024),'inconsistent available GiB'
    assert row['available_kib']>=20*1024*1024 and 20<=row['free_percent']<=100,'insufficient default headroom'
    return row

NODE='/root/.cache/astronomer-032/toolchains/node-v26.11.1-linux-x64/bin/node'
WRAPPER_SHA='aacced12fb2534a4c15d1f7b2898f1b94e2c154dbb8c8182292161755285130b'

GO_IDENTITY={'path': '/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.2.linux-amd64/bin/go', 'sha256': '548d3c32f83fa81152f543eb1526be7884cfe0526eb5e9ce29d3eca14786e7e0', 'device': 2049, 'inode': 2360704, 'size': 17164055, 'mtime_ns': 1791570925918518586}
GO=Path(GO_IDENTITY['path'])
def go_identity():
    assert not GO.is_symlink(), 'selected Go binary symlink drift'
    stat=GO.stat()
    return {'path':str(GO),'sha256':hashlib.sha256(GO.read_bytes()).hexdigest(),'device':stat.st_dev,'inode':stat.st_ino,'size':stat.st_size,'mtime_ns':stat.st_mtime_ns}

def assert_go_identity():
    assert go_identity()==GO_IDENTITY, 'selected Go binary identity drift'

def interrupt(_number,_frame):
    for number in (signal.SIGTERM,signal.SIGINT):signal.signal(number,signal.SIG_IGN)
    raise RuntimeError('owned lane interrupted')

def step_timeout(name,deadline):
    remaining=deadline-time.monotonic()
    assert remaining>0, 'overall owned lane deadline'
    return min(30 if name=='go-version' else (600 if name in ('focused-race','full-race','vet') else 60),remaining)

def main():
    assert len(sys.argv)==2
    output=Path(sys.argv[1]);os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve()),'receipt must be outside source'
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    deadline=time.monotonic()+2200
    source=subprocess.check_output(['git','rev-parse',SOURCE],cwd=ROOT,timeout=10).decode().strip()
    receipt={'source':source,'steps':[],'scope':'Dynamic numeric projections after genuine14FAIL6PASS baseline: focused26 allPASS including existing aggregate300/resource128/protocol compatibility, all current delivery source parents under race/vet/static; no external database, credentials, migration or scanner'}
    def guard(stage):
        check=subprocess.run(['bash','scripts/check-build-capacity.sh','--min-free-gib','20','--min-free-percent','20','--json'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15)
        with (output/'capacity.jsonl').open('a') as stream:stream.write(json.dumps({'stage':stage,'time':time.time(),'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr})+'\n')
        verify_guard(check.stdout,check.returncode)
    def ownership():
        assert_go_identity()
        binding=Path(__file__).with_name('source-bindings.json')
        assert hashlib.sha256(binding.read_bytes()).hexdigest()=='5fd9485862724e120b6ea80f3f88dc31d84a61d3fdddf2e50ba15d461e39eb91','reviewed binding manifest drift'
        for row in json.loads(binding.read_text()):
            path=Path(row['path']);assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256'],'bound input drift'
            if 'inode' in row:
                stat=path.stat();assert (stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns)==(row['device'],row['inode'],row['size'],row['mtime_ns']),'bound tool inode drift'
        assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,timeout=10)==b''
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,timeout=10).decode().strip()==source
    handlers={number:signal.signal(number,interrupt) for number in (signal.SIGTERM,signal.SIGINT)}
    try:
        guard('initial');ownership();receipt['go_before']=go_identity();receipt['source_before']=after.fences.fingerprint(ROOT)
        env=dict(os.environ,GOTOOLCHAIN='go1.27.2',GOWORK='off',GOMAXPROCS='4',GOFLAGS='-p=2 -mod=readonly',GOFIPS140='off')
        receipt['safe_go_environment']={name:env[name] for name in ('GOTOOLCHAIN','GOWORK','GOMAXPROCS','GOFLAGS','GOFIPS140')}
        env['PATH']=str(GO.parent)+':'+env['PATH']
        wrapper=Path(__file__).with_name('check_cached.py')
        assert hashlib.sha256(wrapper.read_bytes()).hexdigest()==WRAPPER_SHA,'cached gate wrapper drift'
        commands=[('go-version',[str(GO),'version']),
          ('focused-race',[str(GO),'test','-race','-json','-count=1','-run','^('+'|'.join(PARENTS)+')$','./internal/agent/delivery']),
          ('full-race',[str(GO),'test','-race','-json','-count=1','./internal/agent/delivery']),
          ('vet',[str(GO),'vet','./internal/agent/delivery']),
          ('boundaries',[NODE,'scripts/check-dependency-boundaries.mjs']),
          ('complexity',[NODE,'scripts/check-complexity-budget.mjs']),
          ('json-governance',[sys.executable,str(wrapper),'json',str(ROOT)]),
          ('sql-governance',[sys.executable,str(wrapper),'sql',str(ROOT)])]
        for name,command in commands:
            step=after.run_step(command,command,env,output/(name+'.log'),guard,ownership,lambda:after.fences.fingerprint(ROOT),timeout=step_timeout(name,deadline))
            receipt['steps'].append({'name':name,**step})
            result=step.get('outcome') or {}
            assert step['source_stable'] and step['final_guard_pass'] and result.get('drained') and not result.get('reason'),'ownership/source/guard fault'
            if name=='go-version':
                assert after.passed(step) and (output/'go-version.log').read_text().strip()=='go version go1.27.2 linux/amd64'
            elif name=='sql-governance':
                assert result['exitCode'] in (0,1),'coupled SQL check process failure'
                if result['exitCode']==1:
                    assert 'sql-governance: SQL owner source changed: internal/delivery/provider/provider.go' in (output/(name+'.log')).read_text(),'unexpected coupled SQL diagnostic'
                receipt['coupled_sql']={'exit_code':result['exitCode'],'status':'PASS' if result['exitCode']==0 else 'FAIL','scope':'Canonical whole-source SQL gate; inherited reviewed provider/Grafana drift remains open, no acceptance or metadata refresh','actual_inventory_sha256':'21d2dc0f176fe79815aab525448c5153886701885ff6721293334bb3e43fb814'}
            else:
                assert result['exitCode']==0,'after gate failure'
                if name=='focused-race':receipt['focused_events']=verify_focus(output/(name+'.log'))
                if name=='full-race':receipt['full_events']=verify_full(output/(name+'.log'))
    except BaseException as error:receipt['failure_category']=type(error).__name__
    finally:
        try:
            receipt['go_after']=go_identity()
            assert receipt['go_after']==GO_IDENTITY and receipt.get('go_before')==GO_IDENTITY, 'selected Go binary identity drift'
            receipt['source_after']=after.fences.fingerprint(ROOT)
            receipt['source_stable']=receipt.get('source_before')==receipt['source_after']
        except BaseException as error:receipt['final_failure_category']=type(error).__name__
        try:
            guard('runner-final');receipt['runner_final_guard_pass']=True
        except BaseException as error:receipt['final_guard_failure_category']=type(error).__name__
        (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        for number,handler in handlers.items():signal.signal(number,handler)
    qualified=len(receipt['steps'])==8 and 'focused_events' in receipt and 'full_events' in receipt and receipt.get('source_stable') and receipt.get('runner_final_guard_pass') and 'failure_category' not in receipt and 'final_failure_category' not in receipt and 'final_guard_failure_category' not in receipt
    print(json.dumps({'receipt':str(output/'receipt.json'),'dynamic_numeric_scoped_qualification_complete':bool(qualified),'coupled_sql_pass':receipt.get('coupled_sql',{}).get('status')=='PASS'}))
    return 0 if qualified else 1

if __name__=='__main__':raise SystemExit(main())
