import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('runner', Path(__file__).with_name('run_before.py'))
runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)


class DynamicBaselineControls(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.log = Path(self.temp.name) / 'before.log'
        self.rows = []
        for name, action in runner.EXPECTED.items():
            text = 'invalid numeric observation projected as usable: aggregate overflow projected as usable: aggregate attached-route overflow projected as usable invalid numeric observation was omitted or relabeled current instead of explicit unavailable'
            self.rows.append({'Action': 'output', 'Package': runner.PACKAGE, 'Test': name, 'Output': text})
            self.rows.append({'Action': action, 'Package': runner.PACKAGE, 'Test': name})
        self.rows.append({'Action': 'fail', 'Package': runner.PACKAGE})
    def evaluate(self):
        self.log.write_text('\n'.join(json.dumps(row) for row in self.rows) + '\n')
        return runner.verify_before(self.log)
    def test_exact_mixed_inventory(self):
        self.assertEqual(self.evaluate()['named_failures'], 14)
        self.assertEqual(self.evaluate()['named_passes'], 6)
    def test_same_failure_names_without_numeric_diagnostic_rejects(self):
        for row in self.rows:
            if row['Action'] == 'output': row['Output'] = 'fixture setup failed'
        with self.assertRaises(AssertionError): self.evaluate()
    def test_missing_extra_duplicate_skip_wrong_package_rejects(self):
        original = copy.deepcopy(self.rows)
        variants = [original[:-3] + original[-1:], original + [original[1]], original + [{'Action': 'pass', 'Package': runner.PACKAGE, 'Test': 'extra'}]]
        changed = copy.deepcopy(original); changed[1]['Action'] = 'skip'; variants.append(changed)
        changed = copy.deepcopy(original); changed[-1]['Package'] = 'wrong'; variants.append(changed)
        changed = copy.deepcopy(original); changed.append({'Action': 'pass', 'Package': runner.PACKAGE}); variants.append(changed)
        for rows in variants:
            self.rows = rows
            with self.subTest(rows=rows), self.assertRaises(AssertionError): self.evaluate()
    def test_runtime_fault_anywhere_rejects(self):
        original = copy.deepcopy(self.rows)
        for text in ('DATA RACE', 'panic:', 'test timed out', 'cleanup failure', 'setup failure'):
            self.rows = copy.deepcopy(original) + [{'Action': 'output', 'Package': runner.PACKAGE, 'Output': text}]
            with self.subTest(text=text), self.assertRaises(AssertionError): self.evaluate()
        self.rows = original + [{'Action': 'build-fail', 'Package': runner.PACKAGE}]
        with self.assertRaises(AssertionError): self.evaluate()
    def test_valid_compatibility_regression_not_expected_failure(self):
        for row in self.rows:
            if row.get('Test') == runner.PARENTS[3] and row['Action'] == 'pass': row['Action'] = 'fail'
        with self.assertRaises(AssertionError): self.evaluate()
    def test_non_event_rejects(self):
        self.rows.append({'unexpected': True})
        with self.assertRaises(AssertionError): self.evaluate()
    def test_non_json_rejects(self):
        self.log.write_text('not JSON\n')
        with self.assertRaises(ValueError): runner.verify_before(self.log)

if __name__ == '__main__': unittest.main()
