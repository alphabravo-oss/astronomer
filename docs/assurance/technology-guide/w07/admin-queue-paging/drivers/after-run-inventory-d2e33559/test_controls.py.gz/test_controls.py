import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

DIRECTORY = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('queue_after', DIRECTORY / 'run_after.py')
runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)

class ClosedInventoryControls(unittest.TestCase):
    def events(self):
        package = runner.base.PACKAGE
        return [{'Action': action, 'Package': package, 'Test': name} for name in runner.INVENTORIES['handler_cases'] for action in ['run', 'pass']] + [{'Action': 'pass', 'Package': package}]
    def verify(self, rows):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / 'events.jsonl'; path.write_text(''.join(json.dumps(row) + '\n' for row in rows))
            return runner.verify_go(path, runner.base.PACKAGE, runner.INVENTORIES['handler_cases'])
    def test_exact_inventory(self): self.assertEqual(self.verify(self.events())['named_passes'], 48)
    def test_missing_duplicate_unknown_and_unterminated_run(self):
        for mutate in [lambda rows: rows.pop(0), lambda rows: rows.insert(0, copy.deepcopy(rows[0])), lambda rows: rows[0].update(Test='TestUnknownRun'), lambda rows: rows.insert(0, {'Action':'run','Package':runner.base.PACKAGE,'Test':'TestUnterminatedRun'})]:
            rows=self.events();mutate(rows)
            with self.assertRaises(AssertionError):self.verify(rows)
    def test_missing_extra_duplicate(self):
        for mutate in [lambda rows: rows.pop(0), lambda rows: rows.insert(0, copy.deepcopy(rows[0])), lambda rows: rows.insert(0, {'Action':'pass','Package':runner.base.PACKAGE,'Test':'TestUnexpected'})]:
            rows=self.events(); mutate(rows)
            with self.assertRaises(AssertionError): self.verify(rows)
    def test_fail_skip_wrong_or_missing_package(self):
        for field,value in [('Action','fail'),('Action','skip'),('Package','other'),('Package',None)]:
            rows=self.events();rows[0][field]=value
            with self.assertRaises(AssertionError):self.verify(rows)
    def test_package_fault_and_non_event(self):
        for extra in [{'Action':'output','Package':runner.base.PACKAGE,'Output':'DATA RACE'}, {'Action':'build-fail','Package':runner.base.PACKAGE}, {'unrelated':'dictionary'}]:
            with self.assertRaises(AssertionError):self.verify(self.events()+[extra])
    def test_package_terminal_conflict(self):
        for extra in ['pass','skip','fail']:
            with self.assertRaises(AssertionError):self.verify(self.events()+[{'Action':extra,'Package':runner.base.PACKAGE}])
    def test_fixture_module_only_external_composition(self):
        original=(runner.ROOT/'go.mod').read_text()
        result=runner.fixture_module(original,runner.ROOT)
        self.assertEqual(result.splitlines()[1:len(original.splitlines())],original.splitlines()[1:])
        self.assertIn('require github.com/alphabravocompany/astronomer-go v0.0.0',result)
        self.assertIn('replace github.com/alphabravocompany/astronomer-go => '+str(runner.ROOT),result)
    def test_api_exact82_and_mutation(self):
        registry=json.loads((runner.ROOT/'deploy/contracts/openapi-current-reviews.json').read_text())
        rows=[{key:row[key] for key in runner.IDENTITY} for row in registry['entries']]
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'report.json';path.write_text(json.dumps(rows));self.assertEqual(runner.verify_api(path)['exact_current_findings'],82)
            for mutate in [lambda r:r.pop(),lambda r:r.append(copy.deepcopy(r[0])),lambda r:r[0].update(text='different'),lambda r:r[0].update(level=1)]:
                changed=copy.deepcopy(rows);mutate(changed);path.write_text(json.dumps(changed))
                with self.assertRaises(AssertionError):runner.verify_api(path)
    def test_browser_exact_titles_files_and_faults(self):
        document={'success':True,'numTotalTests':10,'numPassedTests':10,'numFailedTests':0,'numPendingTests':0,'numTodoTests':0,'testResults':[{'name':str(runner.ROOT/'frontend'/path),'status':'passed','assertionResults':[{'title':title,'status':'passed','failureMessages':[]} for title in titles]} for path,titles in runner.INVENTORIES['browser'].items()]}
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'report.json';log=Path(directory)/'log';log.write_text('');path.write_text(json.dumps(document));self.assertEqual(runner.verify_browser(path,log)['named_passes'],10)
            for mutate in [lambda d:d.update(numPendingTests=1),lambda d:d['testResults'][0]['assertionResults'].pop(),lambda d:d['testResults'][0]['assertionResults'][0].update(title='wrong'),lambda d:d['testResults'][0]['assertionResults'][0].update(status='failed'),lambda d:d.update(unhandledErrors=['failure'])]:
                changed=copy.deepcopy(document);mutate(changed);path.write_text(json.dumps(changed))
                with self.assertRaises(AssertionError):runner.verify_browser(path,log)

if __name__=='__main__':unittest.main()
