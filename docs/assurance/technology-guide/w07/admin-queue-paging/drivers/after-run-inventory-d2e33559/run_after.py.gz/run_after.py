"""Finite scoped W07 queue AFTER; no installs, database mutation, or generation."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

ROOT = Path('/root/astronomer-all/astronomer-032-w07-admin-queues')
SOURCE = 'd2e335592382977b2705df20b22803810a5332fd'
DIRECTORY = Path(__file__).resolve().parent
BASE = Path('/tmp/w07-admin-queue-before-runner-a839a96f/run_before.py')
assert hashlib.sha256(BASE.read_bytes()).hexdigest() == 'fe5ab4296410e9cb14dd8988426a9469adeeda83b7df8e09ac1cc96f834a5ef0'
spec = importlib.util.spec_from_file_location('queue_before', BASE)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
prior, after = base.prior, base.after
NODE, GO = base.NODE, prior.GO
INVENTORIES = json.loads((DIRECTORY / 'inventories.json').read_text())
RELEASED_SHA = 'db9725d5c092c10192e591264a1e0a730a83e4de5a554b5507fa06022352551c'
IDENTITY = ('id', 'text', 'level', 'operation', 'operationId', 'path')
FAULTS = base.FAULTS + ('[build failed]', 'FAIL\t',)


def verify_go(log, package, expected):
    rows = []
    for line in log.read_text().splitlines():
        row = json.loads(line)
        assert isinstance(row, dict) and row.get('Action') in {'start', 'run', 'pause', 'cont', 'output', 'pass', 'fail', 'skip', 'build-output', 'build-fail'}
        assert row.get('Package') == package and row['Action'] != 'build-fail'
        message = row.get('Output', '')
        assert isinstance(message, str) and not any(marker in message for marker in FAULTS)
        rows.append(row)
    runs = [row['Test'] for row in rows if row['Action'] == 'run' and row.get('Test')]
    assert len(runs) == len(set(runs)) == len(expected) and set(runs) == set(expected), 'missing, duplicate, extra or unterminated test run'
    terminals = [row for row in rows if row['Action'] in ('pass', 'fail', 'skip') and row.get('Test')]
    assert len(terminals) == len(expected) and {row['Test'] for row in terminals} == set(expected)
    assert all(row['Action'] == 'pass' for row in terminals)
    packages = [row for row in rows if row['Action'] in ('pass', 'fail', 'skip') and not row.get('Test')]
    assert len(packages) == 1 and packages[0]['Action'] == 'pass'
    return {'named_passes': len(terminals), 'package_passes': 1, 'skips': 0}


def verify_browser(report, log):
    document = json.loads(report.read_text())
    assert document.get('success') is True
    assert document.get('numTotalTests') == document.get('numPassedTests') == 10
    assert document.get('numFailedTests') == document.get('numPendingTests') == document.get('numTodoTests') == 0
    assert not document.get('unhandledErrors') and document.get('numRuntimeErrorTestSuites', 0) == 0
    suites = document['testResults']
    expected = INVENTORIES['browser']
    assert len(suites) == len(expected)
    observed = set()
    for suite in suites:
        path = str(Path(suite['name']).resolve().relative_to(ROOT / 'frontend'))
        assert path in expected and path not in observed and suite['status'] == 'passed'
        observed.add(path)
        cases = suite['assertionResults']
        assert len(cases) == len(expected[path]) and {row['title'] for row in cases} == set(expected[path])
        assert all(row['status'] == 'passed' and not row['failureMessages'] for row in cases)
    assert not any(marker in log.read_text() + json.dumps(document) for marker in base.FAULTS)
    return {'named_passes': 10, 'files_passed': 3, 'skips': 0}


def verify_api(report):
    rows = json.loads(report.read_text())
    registry = json.loads((ROOT / 'deploy/contracts/openapi-current-reviews.json').read_text())
    assert isinstance(rows, list) and len(rows) == 82
    assert 'sha256:' + hashlib.sha256((ROOT / 'docs/openapi.yaml').read_bytes()).hexdigest() == registry['sourceSpecificationDigest']
    keys = [tuple(row[key] for key in IDENTITY) for row in rows]
    reviewed = [tuple(row[key] for key in IDENTITY) for row in registry['entries']]
    assert len(set(keys)) == len(set(reviewed)) == 82 and set(keys) == set(reviewed)
    return {'exact_current_findings': 82, 'new_findings': 0, 'scope': 'released v1.2.1 baseline; actual production review clock and expiry'}


def verify_overlay():
    for name in ('package.json', 'package-lock.json'):
        assert (ROOT / 'frontend' / name).read_bytes() == (base.SHARED.parent / name).read_bytes()
    target = ROOT / 'frontend/node_modules'
    assert target.is_dir() and not target.is_symlink()
    for entry in base.SHARED.iterdir():
        if entry.name not in {'.vite', '.vite-temp', '.cache'}:
            local = target / entry.name
            assert local.is_symlink() and local.resolve() == entry.resolve()
    for name in ('.vite', '.vite-temp', '.cache'):
        local = target / name
        assert local.is_dir() and not local.is_symlink() and local.stat().st_mode & 0o777 == 0o700
    assert hashlib.sha256((target / 'vitest/vitest.mjs').read_bytes()).hexdigest() == base.VITEST_SHA


def fixture_module(original, root):
    lines = original.splitlines(True)
    assert len([row for row in lines if row.startswith('module ')]) == 1
    assert lines[0].strip() == 'module github.com/alphabravocompany/astronomer-go'
    lines[0] = 'module plan032.queue.legacyfixture\n'
    return ''.join(lines) + '\nrequire github.com/alphabravocompany/astronomer-go v0.0.0\nreplace github.com/alphabravocompany/astronomer-go => ' + str(root) + '\n'


def main():
    assert len(sys.argv) == 2
    output = Path(sys.argv[1])
    os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve())
    output.mkdir(mode=0o700, parents=True, exist_ok=False)
    deadline = time.monotonic() + 2800
    receipt = {'source': SOURCE, 'steps': [], 'scope': 'scoped queue handler/race, released SDK layout and request transport, generated-client hook/table boundary, actual v1 API report and source gates; no live browser, database, install, generator or full candidate claim'}
    def guard(stage):
        check = subprocess.run(['bash', 'scripts/check-build-capacity.sh', '--min-free-gib', '20', '--min-free-percent', '20', '--json'], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15)
        with (output / 'capacity.jsonl').open('a') as stream:
            stream.write(json.dumps({'stage': stage, 'time': time.time(), 'exit': check.returncode, 'stdout': check.stdout, 'stderr': check.stderr}) + '\n')
        prior.verify_guard(check.stdout, check.returncode)
    def ownership():
        prior.assert_go_identity()
        assert base.node_identity() == base.NODE_IDENTITY
        assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, timeout=10) == b''
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, timeout=10).decode().strip() == SOURCE
    previous = {number: signal.signal(number, prior.interrupt) for number in (signal.SIGINT, signal.SIGTERM)}
    shared_before = None
    try:
        guard('initial'); ownership(); verify_overlay()
        receipt['go_before'] = prior.go_identity(); receipt['node_before'] = base.node_identity()
        receipt['source_before'] = after.fences.fingerprint(ROOT)
        shared_before = base.shared_snapshot()
        (output / 'shared-before.json').write_text(json.dumps(shared_before) + '\n')
        fixture = output / 'released-sdk'; fixture.mkdir(mode=0o700)
        (fixture / 'go.mod').write_text(fixture_module((ROOT / 'go.mod').read_text(), ROOT))
        (fixture / 'go.sum').write_bytes((ROOT / 'go.sum').read_bytes())
        receipt['external_fixture_module'] = {'source_module_sha256': hashlib.sha256((ROOT / 'go.mod').read_bytes()).hexdigest(), 'fixture_module_sha256': hashlib.sha256((fixture / 'go.mod').read_bytes()).hexdigest(), 'sum_sha256': hashlib.sha256((fixture / 'go.sum').read_bytes()).hexdigest(), 'modifications': 'external module name, require and local replace only; product modules unchanged'}
        env = dict(os.environ, GOTOOLCHAIN='go1.27.2', GOWORK='off', GOMAXPROCS='4', GOFLAGS='-p=2 -mod=readonly', GOFIPS140='off', NO_COLOR='1', VERIFY_ARTIFACT_DIR=str(output / 'openapi'))
        env['PATH'] = str(NODE.parent) + ':' + str(GO.parent) + ':' + env['PATH']
        receipt['selected_environment'] = {key: env[key] for key in ('GOTOOLCHAIN', 'GOWORK', 'GOMAXPROCS', 'GOFLAGS', 'GOFIPS140', 'NO_COLOR', 'VERIFY_ARTIFACT_DIR')}
        tasks = [
            ('go-version', [str(GO), 'version'], ROOT, 30),
            ('node-version', [str(NODE), '--version'], ROOT, 30),
            ('handler-race', [str(GO), 'test', '-race', '-json', '-count=1', '-run', '^(' + '|'.join(INVENTORIES['handler_parents']) + ')$', './internal/handler'], ROOT, 600),
            ('sdk-race', [str(GO), 'test', '-race', '-json', '-count=1', '-run', '^(' + '|'.join(INVENTORIES['sdk_parents']) + ')$', './pkg/astroclient'], ROOT, 300),
            ('released-sdk-source', ['git', 'show', 'v1.2.1:pkg/astroclient/astroclient.gen.go'], ROOT, 30),
            ('released-sdk-generator', [str(GO), 'run', './scripts/sdk-compatibility', str(output / 'released-sdk-source.log'), str(fixture / 'legacy.go'), 'pkg/astroclient/astroclient.gen.go'], ROOT, 120),
            ('released-sdk-compile', [str(GO), 'build', '-o', str(output / 'released-sdk.a'), '.'], fixture, 300),
            ('browser-transport', [str(NODE), str(ROOT / 'frontend/node_modules/vitest/vitest.mjs'), 'run', *INVENTORIES['browser'], '--maxWorkers=1', '--configLoader=runner', '--reporter=json', '--outputFile=' + str(output / 'browser.json')], ROOT / 'frontend', 180),
            ('frontend-types', [str(NODE), str(ROOT / 'frontend/node_modules/typescript/bin/tsc'), '--noEmit'], ROOT / 'frontend', 180),
            ('frontend-lint', [str(NODE), str(ROOT / 'frontend/node_modules/eslint/bin/eslint.js'), *[str(p.relative_to(ROOT / 'frontend')) for p in sorted((ROOT / 'frontend/src/routes/dashboard/settings/operations').glob('*.tsx'))], 'src/lib/api/admin-operations.ts', 'src/lib/api/admin-operations.test.ts', '--max-warnings=0'], ROOT / 'frontend', 120),
            ('v1-openapi', ['bash', 'scripts/openapi-breaking-change.sh', 'v1.2.1:docs/openapi.yaml', 'docs/openapi.yaml'], ROOT, 360),
            ('vet', [str(GO), 'vet', './internal/handler', './pkg/astroclient'], ROOT, 300),
            ('boundaries', [str(NODE), 'scripts/check-dependency-boundaries.mjs'], ROOT, 60),
            ('complexity', [str(NODE), 'scripts/check-complexity-budget.mjs'], ROOT, 60),
            ('code-health', [str(NODE), 'scripts/code-health-inventory.mjs', '--check', '--verify-doc'], ROOT, 60),
            ('operation-inventory', [str(NODE), 'scripts/operation-task-inventory.mjs', '--check', '--verify-doc'], ROOT, 60),
            ('json-governance', ['/usr/bin/python3.14', '-B', str(DIRECTORY / 'check_cached.py'), 'json', str(ROOT), str(output / 'json-actual.json')], ROOT, 90),
            ('coupled-sql', ['/usr/bin/python3.14', '-B', str(DIRECTORY / 'check_cached.py'), 'sql', str(ROOT), str(output / 'sql-actual.json')], ROOT, 90),
        ]
        for name, command, cwd, cap in tasks:
            remaining = deadline - time.monotonic(); assert remaining > 0
            after.ROOT = cwd
            step = after.run_step(command, command, env, output / (name + '.log'), guard, ownership, lambda: after.fences.fingerprint(ROOT), timeout=min(cap, remaining))
            receipt['steps'].append({'name': name, **step})
            outcome = step.get('outcome') or {}
            assert step['source_stable'] and step['final_guard_pass'] and outcome.get('drained') and not outcome.get('reason') and 'exception_category' not in step
            log = output / (name + '.log')
            if name == 'coupled-sql':
                assert outcome['exitCode'] == 1
                assert log.read_text().strip() == 'sql-governance: SQL owner source changed: internal/db/queryextensions/task_outbox_ext.sql.go.tmpl'
                receipt['coupled_sql'] = {'status': 'FAIL', 'scope': 'retained exact source owner mismatch; no metadata renewal or security acceptance', 'actual_sha256': hashlib.sha256((output / 'sql-actual.json').read_bytes()).hexdigest()}
                continue
            assert after.passed(step)
            if name == 'go-version': assert log.read_text().strip() == 'go version go1.27.2 linux/amd64'
            elif name == 'node-version': assert log.read_text().strip() == 'v26.11.1'
            elif name == 'handler-race': receipt['handler_events'] = verify_go(log, base.PACKAGE, INVENTORIES['handler_cases'])
            elif name == 'sdk-race': receipt['sdk_events'] = verify_go(log, 'github.com/alphabravocompany/astronomer-go/pkg/astroclient', INVENTORIES['sdk_cases'])
            elif name == 'released-sdk-source':
                assert hashlib.sha256(log.read_bytes()).hexdigest() == RELEASED_SHA
                receipt['released_sdk_source_sha256'] = RELEASED_SHA
            elif name == 'released-sdk-generator':
                assert re.fullmatch(r'Legacy fixture: \d+ types, \d+ fields, \d+ functions, \d+ methods, \d+ constants\n', log.read_text())
                receipt['released_sdk_fixture_sha256'] = hashlib.sha256((fixture / 'legacy.go').read_bytes()).hexdigest()
            elif name == 'browser-transport': receipt['browser_events'] = verify_browser(output / 'browser.json', log)
            elif name == 'v1-openapi': receipt['v1_api'] = verify_api(output / 'openapi/openapi-breaking-raw.json')
    except BaseException as error:
        receipt['failure_category'] = type(error).__name__
    finally:
        try:
            receipt['go_after'] = prior.go_identity(); receipt['node_after'] = base.node_identity()
            assert receipt.get('go_before') == receipt['go_after'] == prior.GO_IDENTITY
            assert receipt.get('node_before') == receipt['node_after'] == base.NODE_IDENTITY
            receipt['source_after'] = after.fences.fingerprint(ROOT)
            receipt['source_stable'] = receipt.get('source_before') == receipt['source_after']
            shared_after = base.shared_snapshot(); (output / 'shared-after.json').write_text(json.dumps(shared_after) + '\n')
            receipt['shared_dependencies_unchanged'] = shared_before == shared_after
            assert receipt['shared_dependencies_unchanged']
        except BaseException as error: receipt['final_failure_category'] = type(error).__name__
        try: guard('runner-final'); receipt['runner_final_guard_pass'] = True
        except BaseException as error: receipt['final_guard_failure_category'] = type(error).__name__
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        for number, handler in previous.items(): signal.signal(number, handler)
    passed = len(receipt['steps']) == 18 and all(key in receipt for key in ('handler_events', 'sdk_events', 'browser_events', 'v1_api', 'coupled_sql')) and receipt.get('source_stable') and receipt.get('shared_dependencies_unchanged') and receipt.get('runner_final_guard_pass') and not any(key.endswith('failure_category') for key in receipt)
    print(json.dumps({'receipt': str(output / 'receipt.json'), 'scoped_after_qualified': bool(passed), 'coupled_sql': 'FAIL'}))
    return 0 if passed else 1

if __name__ == '__main__': raise SystemExit(main())
