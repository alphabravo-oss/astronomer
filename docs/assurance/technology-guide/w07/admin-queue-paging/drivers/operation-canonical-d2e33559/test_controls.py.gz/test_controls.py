import importlib.util,unittest
from pathlib import Path
spec=importlib.util.spec_from_file_location('driver',Path(__file__).with_name('run_doc.py'));driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
class Controls(unittest.TestCase):
 def test_exact_finite_outputs(self):
  for path in driver.ALLOWED:self.assertEqual(driver.verify_changes([('M',path)],b'',b''),[path])
 def test_immutable_spec_and_sources(self):
  for path in ('docs/openapi.yaml','go.mod','internal/handler/admin_queues.go','oapi-codegen.compatibility-base.overlay.yaml'):
   with self.subTest(path=path),self.assertRaises(AssertionError):driver.verify_changes([('M',path)],b'',b'')
 def test_delete_rename_add_rejected(self):
  path=next(iter(driver.ALLOWED))
  for status in ('D','R','A','T'):
   with self.subTest(status=status),self.assertRaises(AssertionError):driver.verify_changes([(status,path)],b'',b'')
 def test_staged_and_untracked_rejected(self):
  for staged,untracked in ((b'generated',b''),(b'',b'new-file')):
   with self.assertRaises(AssertionError):driver.verify_changes([],staged,untracked)
 def test_output_folders_are_not_authority(self):
  for path in ('internal/db/sqlc/new.go','frontend/src/types/new.generated.ts','pkg/astroclient/other.gen.go'):
   with self.assertRaises(AssertionError):driver.verify_changes([('M',path)],b'',b'')
 def test_all_extension_modes_preserved(self):
  rows=[{'path':str(index),'mode':0o644} for index in range(28)]
  self.assertTrue(driver.verify_modes(rows,rows))
 def test_missing_or_changed_mode_rejected(self):
  rows=[{'path':str(index),'mode':0o644} for index in range(28)]
  for changed in (rows[:-1],[dict(row,mode=0o600) for row in rows]):
   with self.assertRaises(AssertionError):driver.verify_modes(rows,changed)
 def test_original_completed_runtime_receipt_readonly(self):
  proof=driver.verify_original()
  self.assertEqual(proof['completed_passing_steps'],15)
  self.assertIs(proof['runtime_rerun'],False)
if __name__=='__main__':unittest.main()
