import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('runner', Path(__file__).with_name('run_before.py'))
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class BaselineInventoryTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)
        self.rows = []
        for name, diagnostic in runner.GO_CASES.items():
            self.rows.extend([{'Action': 'output', 'Package': runner.PACKAGE, 'Test': name, 'Output': diagnostic},
                              {'Action': 'fail', 'Package': runner.PACKAGE, 'Test': name}])
        self.rows.append({'Action': 'fail', 'Package': runner.PACKAGE})
        self.document = {'success': False, 'numTotalTests': 4, 'numFailedTests': 4, 'numPassedTests': 0,
                         'numPendingTests': 0, 'numTodoTests': 0, 'numRuntimeErrorTestSuites': 0,
                         'testResults': [{'status': 'failed', 'name': str(runner.ROOT / 'frontend/src/routes/dashboard/settings/operations/operations-pagination.test.tsx'),
                                          'assertionResults': [{'title': title, 'status': 'failed', 'failureMessages': [diagnostic]}
                                                               for title, diagnostic in runner.BROWSER_CASES.items()]}]}

    def go(self):
        log = self.path / 'go.log'; log.write_text('\n'.join(json.dumps(row) for row in self.rows) + '\n')
        return runner.verify_go(log)

    def browser(self):
        report = self.path / 'browser.json'; report.write_text(json.dumps(self.document))
        log = self.path / 'browser.log'; log.write_text('expected controlled failures\n')
        return runner.verify_browser(report, log)

    def test_exact_mixed_tools_failure_inventory(self):
        self.assertEqual(self.go()['expected_named_failures'], 2)
        self.assertEqual(self.browser()['expected_named_failures'], 4)

    def test_same_go_names_wrong_diagnostic_rejects(self):
        self.rows[0]['Output'] = 'fixture setup failed'
        with self.assertRaises(AssertionError): self.go()

    def test_go_missing_extra_duplicate_skip_or_wrong_package_rejects(self):
        original = copy.deepcopy(self.rows)
        variants = [original[:-2] + original[-1:], original + [original[1]], original + [{'Action': 'pass', 'Package': runner.PACKAGE, 'Test': 'unexpected'}]]
        for action in ('pass', 'skip'):
            changed = copy.deepcopy(original); changed[1]['Action'] = action; variants.append(changed)
        changed = copy.deepcopy(original); changed[-1]['Package'] = 'wrong'; variants.append(changed)
        changed = copy.deepcopy(original); changed.append({'Action': 'pass', 'Package': runner.PACKAGE}); variants.append(changed)
        for rows in variants:
            self.rows = rows
            with self.subTest(rows=rows), self.assertRaises(AssertionError): self.go()

    def test_go_global_runtime_and_build_failure_rejects(self):
        original = copy.deepcopy(self.rows)
        for marker in ('DATA RACE', 'panic:', 'setup failure', 'cleanup failure', 'test timed out'):
            self.rows = copy.deepcopy(original) + [{'Action': 'output', 'Package': runner.PACKAGE, 'Output': marker}]
            with self.subTest(marker=marker), self.assertRaises(AssertionError): self.go()
        self.rows = original + [{'Action': 'build-fail', 'Package': runner.PACKAGE}]
        with self.assertRaises(AssertionError): self.go()

    def test_browser_same_names_wrong_diagnostic_rejects(self):
        self.document['testResults'][0]['assertionResults'][0]['failureMessages'] = ['fixture setup failed']
        with self.assertRaises(AssertionError): self.browser()

    def test_browser_missing_duplicate_wrong_source_pass_or_skip_rejects(self):
        original = copy.deepcopy(self.document)
        for mode in ('missing', 'duplicate', 'wrong-source', 'passed', 'pending'):
            self.document = copy.deepcopy(original); suite = self.document['testResults'][0]
            if mode == 'missing': suite['assertionResults'].pop()
            elif mode == 'duplicate': suite['assertionResults'][1] = copy.deepcopy(suite['assertionResults'][0])
            elif mode == 'wrong-source': suite['name'] = '/tmp/unrelated.test.tsx'
            else: suite['assertionResults'][0]['status'] = mode
            with self.subTest(mode=mode), self.assertRaises(AssertionError): self.browser()

    def test_browser_runtime_error_rejects(self):
        self.document['unhandledErrors'] = ['synthetic runtime error']
        with self.assertRaises(AssertionError): self.browser()
        self.document.pop('unhandledErrors'); self.document['numRuntimeErrorTestSuites'] = 1
        with self.assertRaises(AssertionError): self.browser()

    def test_browser_global_fault_with_expected_diagnostics_rejects(self):
        self.document['testResults'][0]['message'] = 'Cannot find module unrelated'
        with self.assertRaises(AssertionError): self.browser()

    def test_malformed_output_rejects(self):
        log = self.path / 'broken.log'; log.write_text('not JSON\n')
        with self.assertRaises(ValueError): runner.verify_go(log)
        self.rows.append({'unrelated': True})
        with self.assertRaises(AssertionError): self.go()
        report = self.path / 'report.json'; report.write_text('[]'); log.write_text('')
        with self.assertRaises(AssertionError): runner.verify_browser(report, log)

    def test_default_numeric_capacity_only(self):
        guard = {'total_kib': 100 * 1024 * 1024, 'used_kib': 70 * 1024 * 1024, 'available_kib': 30 * 1024 * 1024,
                 'available_gib': 30, 'free_percent': 30, 'minimum_free_gib': 20, 'minimum_free_percent': 20, 'meets_minimum': True}
        self.assertEqual(runner.prior.verify_guard(json.dumps(guard), 0), guard)
        for update in ({'minimum_free_percent': 19}, {'available_kib': True}, {'available_gib': 29}, {'meets_minimum': False}):
            with self.subTest(update=update), self.assertRaises(AssertionError):
                runner.prior.verify_guard(json.dumps(guard | update), 0)


if __name__ == '__main__': unittest.main()
