"""Unlaunched, finite two-Go/four-route regression baseline; no production edits."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/root/astronomer-all/astronomer-032-w07-admin-queues')
SOURCE = 'a839a96f09bab20baa20923c5184b2b9cb72f42f'
SHARED = Path('/root/astronomer-all/astronomer-032-w07/frontend/node_modules')
REVIEWED = Path('/tmp/w02-charlie-sql-pagination-before-runner-32c58221/run_before.py')
assert hashlib.sha256(REVIEWED.read_bytes()).hexdigest() == '5d80ae8752513b782382b37b7b94ec94c55eba4d806abea0475c28bd1df5b18f'
spec = importlib.util.spec_from_file_location('reviewed_baseline', REVIEWED)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
after = prior.after
PACKAGE = 'github.com/alphabravocompany/astronomer-go/internal/handler'
GO_CASES = {
    'TestAdminQueueDLQPageTwoExposesTask101': 'task 101 unreachable: entries=100 count=100 pages=[1]',
    'TestAdminQueueInspectionFailureCannotAdvertiseHealthyZeroDepth': 'unavailable queue advertised as inspected: status=200',
}
BROWSER_CASES = {
    'reaches row 101 through the actual generated transport and Task outbox table': 'durable-task-101',
    'reaches row 101 through the actual generated transport and Dead-letter table': 'archived-task-101',
    'keeps unavailable inspection as unknown rather than an empty healthy queue listing': 'No queues registered',
    'withholds cached rows and totals when a later outbox page loses permission': 'expected false to be true',
}
NODE_IDENTITY = {'path': '/root/.cache/astronomer-032/toolchains/node-v26.11.1-linux-x64/bin/node', 'sha256': '5a7b8a3cf5ccb57d297519754fd73238f64cf560afd0ef19a2f9bf7384cbb657', 'device': 2049, 'inode': 18176, 'size': 150047368, 'mtime_ns': 1791411607000000000}
NODE = Path(NODE_IDENTITY['path'])
VITEST_SHA = '39db22f579acf5639bbb17a261408debbde03f4692c0c439e77e7f13aeba74d6'
FAULTS = ('DATA RACE', 'panic:', 'test timed out', 'setup failure', 'cleanup failure', 'Failed to load', 'Cannot find module', 'Unhandled Error', 'Unhandled Rejection')

def verify_go(log):
    rows = []
    for line in log.read_text().splitlines():
        row = json.loads(line)
        assert isinstance(row, dict) and row.get('Action') in {'start', 'run', 'pause', 'cont', 'output', 'pass', 'fail', 'skip', 'build-output', 'build-fail'}
        assert row.get('Package') == PACKAGE and row['Action'] != 'build-fail'
        message = row.get('Output', '')
        assert isinstance(message, str) and not any(marker in message for marker in FAULTS)
        rows.append(row)
    terminals = [row for row in rows if row['Action'] in ('pass', 'fail', 'skip') and row.get('Test')]
    assert len(terminals) == 2 and {row['Test'] for row in terminals} == set(GO_CASES)
    assert all(row['Action'] == 'fail' for row in terminals)
    for name, diagnostic in GO_CASES.items():
        assert diagnostic in ''.join(row.get('Output', '') for row in rows if row.get('Test') == name)
    packages = [row for row in rows if row['Action'] in ('pass', 'fail', 'skip') and not row.get('Test')]
    assert len(packages) == 1 and packages[0]['Action'] == 'fail'
    return {'expected_named_failures': 2, 'package_failures': 1, 'skips': 0}

def verify_browser(report, log):
    document = json.loads(report.read_text())
    assert isinstance(document, dict) and document.get('success') is False
    assert document.get('numTotalTests') == document.get('numFailedTests') == 4 and document.get('numPassedTests') == 0
    assert document.get('numPendingTests') == document.get('numTodoTests') == 0
    assert not document.get('unhandledErrors') and document.get('numRuntimeErrorTestSuites', 0) == 0
    suites = document['testResults']
    assert len(suites) == 1 and suites[0]['status'] == 'failed'
    assert Path(suites[0]['name']).resolve() == ROOT / 'frontend/src/routes/dashboard/settings/operations/operations-pagination.test.tsx'
    cases = suites[0]['assertionResults']
    assert len(cases) == 4 and {row['title'] for row in cases} == set(BROWSER_CASES)
    assert all(row['status'] == 'failed' for row in cases)
    for row in cases:
        message = '\n'.join(row['failureMessages'])
        assert BROWSER_CASES[row['title']] in message, 'owned pagination diagnostic absent'
    text = log.read_text() + json.dumps(document)
    assert not any(marker in text for marker in FAULTS), 'browser runtime/setup fault'
    return {'expected_named_failures': 4, 'failed_files': 1, 'skips': 0}

def node_identity():
    assert not NODE.is_symlink()
    stat = NODE.stat()
    return {'path': str(NODE), 'sha256': hashlib.sha256(NODE.read_bytes()).hexdigest(), 'device': stat.st_dev, 'inode': stat.st_ino, 'size': stat.st_size, 'mtime_ns': stat.st_mtime_ns}

def shared_snapshot():
    rows = []
    for parent, directories, files in os.walk(SHARED, followlinks=False):
        for name in sorted(directories + files):
            path = Path(parent) / name
            stat = path.lstat()
            rows.append([str(path.relative_to(SHARED)), stat.st_mode, stat.st_size, stat.st_mtime_ns, stat.st_ino, os.readlink(path) if path.is_symlink() else None])
    return sorted(rows)

def overlay():
    for name in ('package.json', 'package-lock.json'):
        assert (ROOT / 'frontend' / name).read_bytes() == (SHARED.parent / name).read_bytes(), 'read-only dependency lock mismatch'
    target = ROOT / 'frontend/node_modules'
    assert not target.exists() and not target.is_symlink(), 'fresh caller-local overlay required'
    target.mkdir(mode=0o700)
    for entry in SHARED.iterdir():
        if entry.name not in {'.vite', '.vite-temp', '.cache'}:
            (target / entry.name).symlink_to(entry)
    for name in ('.vite', '.vite-temp', '.cache'):
        (target / name).mkdir(mode=0o700)
    assert hashlib.sha256((target / 'vitest/vitest.mjs').read_bytes()).hexdigest() == VITEST_SHA

def main():
    assert len(sys.argv) == 2
    output = Path(sys.argv[1])
    os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve())
    output.mkdir(mode=0o700, parents=True, exist_ok=False)
    deadline = time.monotonic() + 1000
    receipt = {'source': SOURCE, 'steps': [], 'scope': 'two actual handler failures plus four real generated-Axios/hook/table failures; unchanged production; no product browser, database, mutation or generator'}
    def guard(stage):
        check = subprocess.run(['bash', 'scripts/check-build-capacity.sh', '--min-free-gib', '20', '--min-free-percent', '20', '--json'], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15)
        with (output / 'capacity.jsonl').open('a') as stream:
            stream.write(json.dumps({'stage': stage, 'time': time.time(), 'exit': check.returncode, 'stdout': check.stdout, 'stderr': check.stderr}) + '\n')
        prior.verify_guard(check.stdout, check.returncode)
    def ownership():
        prior.assert_go_identity()
        assert node_identity() == NODE_IDENTITY
        assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, timeout=10) == b''
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, timeout=10).decode().strip() == SOURCE
    previous = {number: signal.signal(number, prior.interrupt) for number in (signal.SIGINT, signal.SIGTERM)}
    shared_before = None
    try:
        guard('initial'); ownership()
        receipt['go_before'] = prior.go_identity(); receipt['node_before'] = node_identity()
        receipt['source_before'] = after.fences.fingerprint(ROOT)
        shared_before = shared_snapshot()
        (output / 'shared-before.json').write_text(json.dumps(shared_before) + '\n')
        overlay(); ownership()
        env = dict(os.environ, GOTOOLCHAIN='go1.27.2', GOWORK='off', GOMAXPROCS='4', GOFLAGS='-p=2 -mod=readonly', GOFIPS140='off', NO_COLOR='1')
        env['PATH'] = str(NODE.parent) + ':' + str(prior.GO.parent) + ':' + env['PATH']
        receipt['selected_environment'] = {key: env[key] for key in ('GOTOOLCHAIN', 'GOWORK', 'GOMAXPROCS', 'GOFLAGS', 'GOFIPS140', 'NO_COLOR')}
        tasks = [
            ('go-version', [str(prior.GO), 'version'], ROOT, 30),
            ('node-version', [str(NODE), '--version'], ROOT, 30),
            ('go-before', [str(prior.GO), 'test', '-race', '-json', '-count=1', '-run', '^(' + '|'.join(GO_CASES) + ')$', './internal/handler'], ROOT, 600),
            ('browser-before', [str(NODE), str(ROOT / 'frontend/node_modules/vitest/vitest.mjs'), 'run', 'src/routes/dashboard/settings/operations/operations-pagination.test.tsx', '--maxWorkers=1', '--configLoader=runner', '--reporter=json', '--outputFile=' + str(output / 'browser.json')], ROOT / 'frontend', 180),
        ]
        for name, command, cwd, cap in tasks:
            remaining = deadline - time.monotonic(); assert remaining > 0
            after.ROOT = cwd
            step = after.run_step(command, command, env, output / (name + '.log'), guard, ownership, lambda: after.fences.fingerprint(ROOT), timeout=min(cap, remaining))
            receipt['steps'].append({'name': name, **step})
            outcome = step.get('outcome') or {}
            assert step['source_stable'] and step['final_guard_pass'] and outcome.get('drained') and not outcome.get('reason') and 'exception_category' not in step
            if name == 'go-version':
                assert after.passed(step) and (output / (name + '.log')).read_text().strip() == 'go version go1.27.2 linux/amd64'
            elif name == 'node-version':
                assert after.passed(step) and (output / (name + '.log')).read_text().strip() == 'v26.11.1'
            elif name == 'go-before':
                assert outcome['exitCode'] == 1; receipt['go_events'] = verify_go(output / (name + '.log'))
            else:
                assert outcome['exitCode'] == 1; receipt['browser_events'] = verify_browser(output / 'browser.json', output / (name + '.log'))
    except BaseException as error:
        receipt['failure_category'] = type(error).__name__
    finally:
        try:
            receipt['go_after'] = prior.go_identity(); receipt['node_after'] = node_identity()
            assert receipt.get('go_before') == receipt['go_after'] == prior.GO_IDENTITY
            assert receipt.get('node_before') == receipt['node_after'] == NODE_IDENTITY
            receipt['source_after'] = after.fences.fingerprint(ROOT)
            receipt['source_stable'] = receipt.get('source_before') == receipt['source_after']
            shared_after = shared_snapshot(); (output / 'shared-after.json').write_text(json.dumps(shared_after) + '\n')
            receipt['shared_dependencies_unchanged'] = shared_before == shared_after
            assert receipt['shared_dependencies_unchanged']
        except BaseException as error:
            receipt['final_failure_category'] = type(error).__name__
        try:
            guard('runner-final'); receipt['runner_final_guard_pass'] = True
        except BaseException as error:
            receipt['final_guard_failure_category'] = type(error).__name__
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        for number, handler in previous.items(): signal.signal(number, handler)
    passed = len(receipt['steps']) == 4 and 'go_events' in receipt and 'browser_events' in receipt and receipt.get('source_stable') and receipt.get('shared_dependencies_unchanged') and receipt.get('runner_final_guard_pass') and not any(key.endswith('failure_category') for key in receipt)
    print(json.dumps({'receipt': str(output / 'receipt.json'), 'baseline_qualified': bool(passed)}))
    return 0 if passed else 1

if __name__ == '__main__': raise SystemExit(main())
