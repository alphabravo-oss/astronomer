"""Unlaunched canonical generator-only lane; generated diffs require review."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

DIRECTORY = Path(__file__).resolve().parent
REVIEWED = Path('/tmp/w07-admin-queue-before-runner-a839a96f/run_before.py')
assert hashlib.sha256(REVIEWED.read_bytes()).hexdigest() == 'fe5ab4296410e9cb14dd8988426a9469adeeda83b7df8e09ac1cc96f834a5ef0'
spec = importlib.util.spec_from_file_location('reviewed_before', REVIEWED)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
ROOT = prior.ROOT
SOURCE = 'b413df3d7c816f82742e23c54c0eb00095269eec'
ALLOWED = set(json.loads((DIRECTORY / 'allowed-outputs.json').read_text()))


def verify_changes(changes, staged, untracked):
    assert not staged and not untracked, 'unexpected index/untracked mutation'
    assert all(status == 'M' and path in ALLOWED for status, path in changes), 'generator modified/deleted unapproved source'
    return sorted(path for _, path in changes)


def changed_paths():
    raw = subprocess.check_output(['git', 'diff', '--no-renames', '--name-status', '-z'], cwd=ROOT, timeout=15).decode().split('\0')
    assert raw[-1] == '' and len(raw[:-1]) % 2 == 0, 'malformed changed-file inventory'
    changes = list(zip(raw[:-1:2], raw[1:-1:2]))
    staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=ROOT, timeout=15)
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT, timeout=15)
    return verify_changes(changes, staged, untracked)


def inputs():
    binding = DIRECTORY / 'source-bindings.json'
    assert hashlib.sha256(binding.read_bytes()).hexdigest() == BINDING_SHA, 'reviewed input manifest drift'
    assert hashlib.sha256((DIRECTORY / 'allowed-outputs.json').read_bytes()).hexdigest() == ALLOWED_SHA, 'finite output inventory drift'
    rows = json.loads(binding.read_text())
    for row in rows:
        path = Path(row['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], 'canonical input/tool drift'
        if 'inode' in row:
            value = path.stat()
            assert (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns) == (row['device'], row['inode'], row['size'], row['mtime_ns']), 'bound tool inode drift'
    prior.prior.assert_go_identity()
    assert prior.node_identity() == prior.NODE_IDENTITY, 'selected Node drift'
    return {'binding_sha256': BINDING_SHA, 'go': prior.prior.go_identity(), 'node': prior.node_identity()}


def extension_modes():
    paths = sorted(path for path in ALLOWED if path.startswith('internal/db/sqlc/'))
    assert len(paths) == 28, 'finite extension inventory drift'
    rows = []
    for path in paths:
        value = (ROOT / path).lstat()
        assert stat.S_ISREG(value.st_mode), 'extension output is not a regular file'
        rows.append({'path': path, 'mode': stat.S_IMODE(value.st_mode)})
    return rows


def verify_modes(before, after):
    assert len(before) == len(after) == 28 and before == after, 'SQL extension modes changed'
    assert len({row['path'] for row in before}) == 28, 'duplicate extension mode inventory'
    return True


def main():
    assert len(sys.argv) == 2
    output = Path(sys.argv[1]); os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve())
    output.mkdir(mode=0o700, exist_ok=False)
    deadline = time.monotonic() + 900
    receipt = {'source': SOURCE, 'steps': [], 'scope': 'canonical OpenAPI/Go SDK/browser and sqlc extension/doc generation only; generated diff remains pending full review, no application test, API compatibility approval, database or scanner'}
    def guard(stage):
        row = subprocess.run(['bash', 'scripts/check-build-capacity.sh', '--min-free-gib', '20', '--min-free-percent', '20', '--json'], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15)
        with (output / 'capacity.jsonl').open('a') as stream:
            stream.write(json.dumps({'stage': stage, 'time': time.time(), 'exit': row.returncode, 'stdout': row.stdout, 'stderr': row.stderr}) + '\n')
        prior.prior.verify_guard(row.stdout, row.returncode)
    def ownership():
        inputs(); changed_paths()
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, timeout=10).decode().strip() == SOURCE, 'source HEAD drift'
        for name in ('package.json', 'package-lock.json'):
            assert (ROOT / 'frontend' / name).read_bytes() == (prior.SHARED.parent / name).read_bytes(), 'dependency lock drift'
    previous = {number: signal.signal(number, prior.prior.interrupt) for number in (signal.SIGINT, signal.SIGTERM)}
    shared_before = None
    try:
        guard('initial'); ownership()
        assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, timeout=10) == b'', 'generator source must start clean'
        receipt['source_before'] = prior.after.fences.fingerprint(ROOT)
        receipt['inputs_before'] = inputs()
        receipt['extension_modes_before'] = extension_modes()
        shared_before = prior.shared_snapshot()
        (output / 'shared-before.json').write_text(json.dumps(shared_before) + '\n')
        env = dict(os.environ, GOTOOLCHAIN='go1.27.2', GOWORK='off', GOMAXPROCS='4', GOFLAGS='-p=2 -mod=readonly', GOFIPS140='off', PYTHONDONTWRITEBYTECODE='1', NO_COLOR='1')
        for key in ('MAKEFLAGS', 'MAKEOVERRIDES', 'MAKEFILES', 'MFLAGS', 'NODE_OPTIONS', 'NODE_PATH', 'PYTHONPATH', 'PYTHONHOME'):
            env.pop(key, None)
        env['PYTHONNOUSERSITE'] = '1'
        env['OAPI_CODEGEN_VERSION'] = 'v2.5.1'
        env['OAPI_CODEGEN'] = str(prior.prior.GO) + ' run github.com/oapi-codegen/oapi-codegen/v2/cmd/oapi-codegen@v2.5.1'
        env['PATH'] = str(prior.NODE.parent) + ':' + str(prior.prior.GO.parent) + ':/usr/bin:/bin'
        receipt['selected_environment'] = {name: env[name] for name in ('GOTOOLCHAIN', 'GOWORK', 'GOMAXPROCS', 'GOFLAGS', 'GOFIPS140', 'PYTHONDONTWRITEBYTECODE', 'NO_COLOR', 'PYTHONNOUSERSITE', 'OAPI_CODEGEN_VERSION', 'OAPI_CODEGEN')}
        tasks = [
            ('go-version', [str(prior.prior.GO), 'version'], 30),
            ('node-version', [str(prior.NODE), '--version'], 30),
            ('openapi-generate', ['/usr/bin/make', 'openapi-generate'], 600),
            ('sqlc-extensions-generate', ['/usr/bin/make', 'sqlc-extensions-generate'], 45),
            ('code-health-inventory', [str(prior.NODE), 'scripts/code-health-inventory.mjs', '--write'], 45),
            ('operation-task-inventory', [str(prior.NODE), 'scripts/operation-task-inventory.mjs', '--write'], 45),
            ('format-generated-docs', [str(prior.NODE), 'frontend/node_modules/prettier/bin/prettier.cjs', '--write', 'docs/rancher-quality-phase0-code-health-inventory.md', 'docs/rancher-quality-phase0-operation-task-inventory.md'], 30),
            ('sqlc-extension-freshness', ['/usr/bin/make', 'sqlc-extensions-check'], 30),
        ]
        for name, command, cap in tasks:
            remaining = deadline - time.monotonic(); assert remaining > 0, 'overall generator deadline'
            # Canonical inputs remain immutable; generated output changes are
            # expected and recorded through full source fingerprints separately.
            prior.after.ROOT = ROOT
            step = prior.after.run_step(command, command, env, output / (name + '.log'), guard, ownership, inputs, timeout=min(cap, remaining))
            receipt['steps'].append({'name': name, **step})
            assert prior.after.passed(step), 'generator failed; originals retained'
            if name == 'go-version': assert (output / (name + '.log')).read_text().strip() == 'go version go1.27.2 linux/amd64'
            if name == 'node-version': assert (output / (name + '.log')).read_text().strip() == 'v26.11.1'
            ownership()
        receipt['changed_generated_paths'] = changed_paths()
        receipt['generation_pass'] = True
    except BaseException as error:
        receipt['failure_category'] = type(error).__name__
    finally:
        try:
            ownership(); receipt['inputs_after'] = inputs()
            receipt['source_after'] = prior.after.fences.fingerprint(ROOT)
            receipt['canonical_inputs_stable'] = receipt.get('inputs_before') == receipt['inputs_after']
            receipt['extension_modes_after'] = extension_modes()
            receipt['extension_modes_unchanged'] = verify_modes(receipt.get('extension_modes_before', []), receipt['extension_modes_after'])
            receipt['changed_generated_paths'] = changed_paths()
            shared_after = prior.shared_snapshot()
            (output / 'shared-after.json').write_text(json.dumps(shared_after) + '\n')
            receipt['shared_metadata_unchanged'] = shared_before == shared_after
        except BaseException as error:
            receipt['final_failure_category'] = type(error).__name__
        try:
            guard('runner-final'); receipt['runner_final_guard_pass'] = True
        except BaseException as error:
            receipt['final_guard_failure_category'] = type(error).__name__
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        for number, handler in previous.items(): signal.signal(number, handler)
    qualified = bool(receipt.get('generation_pass') and receipt.get('extension_modes_unchanged') and receipt.get('canonical_inputs_stable') and receipt.get('shared_metadata_unchanged') and receipt.get('runner_final_guard_pass') and not any(name in receipt for name in ('failure_category', 'final_failure_category', 'final_guard_failure_category')))
    print(json.dumps({'receipt': str(output / 'receipt.json'), 'generation_scoped_pass': qualified, 'generated_diff_review_pending': True}))
    return 0 if qualified else 1


BINDING_SHA = '4ccada9c34cff31f6d77661cd87987d01f511defd6ba0f89564373b52901a067'
ALLOWED_SHA = 'b08156ccd4dcce6237e49c896b9f9229a32a2c76a0380c47f731d128039c878b'
if __name__ == '__main__':
    raise SystemExit(main())
