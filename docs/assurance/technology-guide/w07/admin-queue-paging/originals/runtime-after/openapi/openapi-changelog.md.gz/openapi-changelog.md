# API Changelog 1.0 vs. 1.0


## API Changes

### POST /api/v1/admin/alerting/inhibitions/
- :warning: the request property `source_matchers` became required
- :warning: the request property `target_matchers` became required
- :warning: the `source_matchers` request property's minItems was set to `1`
- :warning: the `target_matchers` request property's minItems was set to `1`
- :warning: the `equal_labels/items/` request property's minLength was set to `1`
- :warning: the `name` request property's minLength was set to `1`
- :warning: the `source_matchers/items/label` request property's minLength was set to `1`
- :warning: the `target_matchers/items/label` request property's minLength was set to `1`
- :warning: added the pattern `\S` to the request property `equal_labels/items/`
- :warning: added the pattern `\S` to the request property `source_matchers/items/label`
- :warning: added the pattern `\S` to the request property `target_matchers/items/label`
-  the request property `enabled` became nullable
-  the request property `equal_labels` became nullable
-  the `enabled` request property default value `true` was added
-  the `is_regex` request property default value `false` was added
-  the `is_regex` request property default value `false` was added
-  added the non-success response with the status `422`


### PUT /api/v1/admin/alerting/inhibitions/{id}/
- :warning: the request property `source_matchers` became required
- :warning: the request property `target_matchers` became required
- :warning: the `source_matchers` request property's minItems was set to `1`
- :warning: the `target_matchers` request property's minItems was set to `1`
- :warning: the `equal_labels/items/` request property's minLength was set to `1`
- :warning: the `name` request property's minLength was set to `1`
- :warning: the `source_matchers/items/label` request property's minLength was set to `1`
- :warning: the `target_matchers/items/label` request property's minLength was set to `1`
- :warning: added the pattern `\S` to the request property `equal_labels/items/`
- :warning: added the pattern `\S` to the request property `source_matchers/items/label`
- :warning: added the pattern `\S` to the request property `target_matchers/items/label`
-  the request property `enabled` became nullable
-  the request property `equal_labels` became nullable
-  the `enabled` request property default value `true` was added
-  the `is_regex` request property default value `false` was added
-  the `is_regex` request property default value `false` was added
-  added the non-success response with the status `422`


### GET /api/v1/admin/queues/{queue}/dlq
-  added the new optional `query` request parameter `page`
-  added the optional property `allOf[subschema #2]/pagination` to the response with the `200` status


### GET /api/v1/catalog/charts/
- :warning: for the `query` request parameter `offset`, the max was set to `10000.00`
- :warning: removed `#/components/schemas/PageEnvelope` from the response body `allOf` list for the response status `200`
-  added the new optional `query` request parameter `cursor`
-  added `#/components/schemas/SignedCursorPageEnvelope` to the response body `allOf` list for the response status `200`


### GET /api/v1/controllers/alerts
- :warning: for the `query` request parameter `offset`, the max was set to `10000.00`
- :warning: the `pagination/next_cursor` response property's maxLength was increased from `1024` to `4096` for the response status `200`
-  added the new optional `query` request parameter `cursor`


### GET /api/v1/controllers/silences
- :warning: for the `query` request parameter `offset`, the max was set to `10000.00`
- :warning: the `pagination/next_cursor` response property's maxLength was increased from `1024` to `4096` for the response status `200`
-  added the new optional `query` request parameter `cursor`


### GET /api/v1/delivery/rollouts/
- :warning: added the new `aborted` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `awaiting_approval` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `draft` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `failed` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `paused` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `progressing` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `queued` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `rejected` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `resolving` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `rollback_failed` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `rolled_back` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `rolling_back` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `succeeded` enum value to the `data/items/state` response property for the response status `200`


### GET /api/v1/delivery/rollouts/{id}/
- :warning: added the new `aborted` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `awaiting_approval` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `draft` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `failed` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `paused` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `progressing` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `queued` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `rejected` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `resolving` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `rollback_failed` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `rolled_back` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `rolling_back` enum value to the `data/rollout/state` response property for the response status `200`
- :warning: added the new `succeeded` enum value to the `data/rollout/state` response property for the response status `200`


### GET /api/v1/delivery/rollouts/{id}/clusters/
- :warning: added the new `aborted` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `acknowledged` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `blocked` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `failed` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `pending` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `ready` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `ready_previous` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `reconciling` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `released` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `rollback_failed` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `rolling_back` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `skipped` enum value to the `data/items/state` response property for the response status `200`
- :warning: added the new `timed_out` enum value to the `data/items/state` response property for the response status `200`


### GET /api/v1/delivery/system/compatibility/
- :warning: added the new `aborted` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `awaiting_approval` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `draft` enum value to the `data/current_release/allOf[#/components/schemas/DeliverySystemRelease]/state` response property for the response status `200`
- :warning: added the new `draft` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `failed` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `paused` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `progressing` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `queued` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `released` enum value to the `data/current_release/allOf[#/components/schemas/DeliverySystemRelease]/state` response property for the response status `200`
- :warning: added the new `retired` enum value to the `data/current_release/allOf[#/components/schemas/DeliverySystemRelease]/state` response property for the response status `200`
- :warning: added the new `revoked` enum value to the `data/current_release/allOf[#/components/schemas/DeliverySystemRelease]/state` response property for the response status `200`
- :warning: added the new `rollback_failed` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `rolled_back` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `rolling_back` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`
- :warning: added the new `succeeded` enum value to the `data/current_rollout/allOf[#/components/schemas/DeliverySystemRollout]/state` response property for the response status `200`






