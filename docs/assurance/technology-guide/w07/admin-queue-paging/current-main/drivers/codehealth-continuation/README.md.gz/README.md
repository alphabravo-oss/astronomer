# Current W07 canonical code-health continuation

Source-only, unlaunched on clean c137c3cb386f0d368888490669d529b412d1ea14. Execute only after root allocates the sole native lane:

    python3 -B /tmp/w07-admin-queue-codehealth-continuation-c137c3cb/run_doc.py /tmp/w07-admin-queue-codehealth-continuation-c137c3cb-run1

Five finite steps within 420 seconds: canonical code-health write, exact canonical code-health check, unchanged operation inventory check, cached full JSON check, cached full SQL check. Only docs/rancher-quality-phase0-code-health-inventory.md may change. No formatter, compilation, runtime repeat, installation, API generation or source/policy rewrite. Canonical MD diff is retained for full review before commit.

The actual current run2 receipt 50689737 and every original gate log are hash-bound. Its strict handler 48 and SDK 12 case inventories are independently reparsed; version, vet, boundary and complexity pass, code-health's exact stale diagnostic remains a historical failure. Capacity-stopped run1 remains immutable. The original full frozen source fingerprint is required before regeneration. The writer's permitted document mutation is recorded separately from immutable input binding, full before/after source fingerprints and exact Git changed-file inventory.

All 28 extension modes and the shared read-only package entry graph must remain unchanged, selected Go/Node/cached-parser identities remain bound, default numeric 20 GiB / 20% guards remain fatal and the reviewed held-leader helper drains every child. No guessed first SQL diagnostic is accepted: actual SQL status/diagnostic/full inventory are retained. If SQL is still FAIL the runner returns 1, records failure_accepted=false and makes no coupled static PASS claim. Every other step must pass; malformed or failed process ownership cannot receive credit.
