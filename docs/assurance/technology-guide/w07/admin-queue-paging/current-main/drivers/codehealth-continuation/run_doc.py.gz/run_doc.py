"""Unlaunched canonical generator-only lane; generated diffs require review."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

DIRECTORY = Path(__file__).resolve().parent
REVIEWED = Path('/tmp/w07-admin-queue-before-runner-a839a96f/run_before.py')
assert hashlib.sha256(REVIEWED.read_bytes()).hexdigest() == 'fe5ab4296410e9cb14dd8988426a9469adeeda83b7df8e09ac1cc96f834a5ef0'
spec = importlib.util.spec_from_file_location('reviewed_before', REVIEWED)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
ROOT = Path('/root/astronomer-all/astronomer-032-w07-current-main')
SOURCE = 'c137c3cb386f0d368888490669d529b412d1ea14'
ALLOWED = set(json.loads((DIRECTORY / 'allowed-outputs.json').read_text()))


def verify_changes(changes, staged, untracked):
    assert not staged and not untracked, 'unexpected index/untracked mutation'
    assert all(status == 'M' and path in ALLOWED for status, path in changes), 'generator modified/deleted unapproved source'
    return sorted(path for _, path in changes)


def changed_paths():
    raw = subprocess.check_output(['git', 'diff', '--no-renames', '--name-status', '-z'], cwd=ROOT, timeout=15).decode().split('\0')
    assert raw[-1] == '' and len(raw[:-1]) % 2 == 0, 'malformed changed-file inventory'
    changes = list(zip(raw[:-1:2], raw[1:-1:2]))
    staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only', '-z'], cwd=ROOT, timeout=15)
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'], cwd=ROOT, timeout=15)
    return verify_changes(changes, staged, untracked)


def inputs():
    binding = DIRECTORY / 'source-bindings.json'
    assert hashlib.sha256(binding.read_bytes()).hexdigest() == BINDING_SHA, 'reviewed input manifest drift'
    assert hashlib.sha256((DIRECTORY / 'allowed-outputs.json').read_bytes()).hexdigest() == ALLOWED_SHA, 'finite output inventory drift'
    rows = json.loads(binding.read_text())
    for row in rows:
        path = Path(row['path'])
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], 'canonical input/tool drift'
        if 'inode' in row:
            value = path.stat()
            assert (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns) == (row['device'], row['inode'], row['size'], row['mtime_ns']), 'bound tool inode drift'
    prior.prior.assert_go_identity()
    assert prior.node_identity() == prior.NODE_IDENTITY, 'selected Node drift'
    return {'binding_sha256': BINDING_SHA, 'go': prior.prior.go_identity(), 'node': prior.node_identity()}


def extension_modes():
    paths = sorted(json.loads((DIRECTORY / 'extensions.json').read_text()))
    assert len(paths) == 28, 'finite extension inventory drift'
    rows = []
    for path in paths:
        value = (ROOT / path).lstat()
        assert stat.S_ISREG(value.st_mode), 'extension output is not a regular file'
        rows.append({'path': path, 'mode': stat.S_IMODE(value.st_mode)})
    return rows


def verify_modes(before, after):
    assert len(before) == len(after) == 28 and before == after, 'SQL extension modes changed'
    assert len({row['path'] for row in before}) == 28, 'duplicate extension mode inventory'
    return True


def verify_original():
    directory = Path('/tmp/w07-admin-queue-current-main-c137c3cb-run2')
    path = directory / 'receipt.json'
    expected = '5068973749dd90095bc3169d65661bd995a02e2219c52162692a4ea83f1b1c21'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    row = json.loads(path.read_text())
    assert row['source'] == SOURCE and row.get('failure_category') == 'AssertionError'
    assert row['source_before'] == row['source_after'] == prior.after.fences.fingerprint(ROOT)
    assert row['source_stable'] and row['runner_final_guard_pass']
    assert [step['name'] for step in row['steps']] == ['go-version', 'node-version', 'handler-race', 'sdk-race', 'vet', 'boundaries', 'complexity', 'code-health']
    for index, step in enumerate(row['steps']):
        assert hashlib.sha256((directory / (step['name'] + '.log')).read_bytes()).hexdigest() == step['log_sha256']
        assert step['source_stable'] and step['final_guard_pass']
        assert step['outcome']['drained'] and step['outcome']['leaderHeldUntilDrain']
        assert not step['outcome']['reason'] and not step['outcome']['guardException']
        assert not step['outcome']['liveDescendantsAfterDrain']
        if index < 7:
            assert prior.after.passed(step)
        else:
            assert step['outcome']['exitCode'] == 1
    expected_diagnostic = 'docs/rancher-quality-phase0-code-health-inventory.md is stale.\nRun: node scripts/code-health-inventory.mjs --write\n'
    assert (directory / 'code-health.log').read_text() == expected_diagnostic
    current_path = Path('/tmp/w07-admin-queue-current-main-runner-c137c3cb/run_current.py')
    assert hashlib.sha256(current_path.read_bytes()).hexdigest() == 'b4c664f2669598db53fe4897a0b442002d463caf2539eb1f2df6eba01d850aa7'
    spec = importlib.util.spec_from_file_location('reviewed_current', current_path)
    current = importlib.util.module_from_spec(spec); spec.loader.exec_module(current)
    handler = current.qualified.verify_go(directory / 'handler-race.log', current.base.PACKAGE, current.INVENTORIES['handler_cases'])
    sdk = current.qualified.verify_go(directory / 'sdk-race.log', 'github.com/alphabravocompany/astronomer-go/pkg/astroclient', current.INVENTORIES['sdk_cases'])
    assert handler == row['handler_events'] == {'named_passes': 48, 'package_passes': 1, 'skips': 0}
    assert sdk == row['sdk_events'] == {'named_passes': 12, 'package_passes': 1, 'skips': 0}
    return {'original_failed_receipt_sha256': expected, 'completed_passing_steps': 7,
            'failed_codehealth_inventory_retained': True, 'handler_events': handler,
            'sdk_events': sdk, 'runtime_rerun': False}


def main():
    assert len(sys.argv) == 2
    output = Path(sys.argv[1]); os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve())
    output.mkdir(mode=0o700, exist_ok=False)
    deadline = time.monotonic() + 420
    receipt = {'source': SOURCE, 'steps': [], 'scope': 'Canonical code-health document regeneration and remaining operation/JSON/SQL static checks only; retains current handler/SDK/vet/boundary/complexity proof without runtime repetition'}
    def guard(stage):
        row = subprocess.run(['bash', 'scripts/check-build-capacity.sh', '--min-free-gib', '20', '--min-free-percent', '20', '--json'], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=15)
        with (output / 'capacity.jsonl').open('a') as stream:
            stream.write(json.dumps({'stage': stage, 'time': time.time(), 'exit': row.returncode, 'stdout': row.stdout, 'stderr': row.stderr}) + '\n')
        prior.prior.verify_guard(row.stdout, row.returncode)
    def ownership():
        inputs(); changed_paths()
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, timeout=10).decode().strip() == SOURCE, 'source HEAD drift'
        for name in ('package.json', 'package-lock.json'):
            assert (ROOT / 'frontend' / name).read_bytes() == (prior.SHARED.parent / name).read_bytes(), 'dependency lock drift'
    previous = {number: signal.signal(number, prior.prior.interrupt) for number in (signal.SIGINT, signal.SIGTERM)}
    shared_before = None
    try:
        guard('initial'); ownership()
        assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, timeout=10) == b'', 'generator source must start clean'
        receipt['source_before'] = prior.after.fences.fingerprint(ROOT)
        receipt['retained_completed_runtime'] = verify_original()
        receipt['inputs_before'] = inputs()
        receipt['extension_modes_before'] = extension_modes()
        shared_before = prior.shared_snapshot()
        (output / 'shared-before.json').write_text(json.dumps(shared_before) + '\n')
        env = dict(os.environ, GOTOOLCHAIN='go1.27.2', GOWORK='off', GOMAXPROCS='4', GOFLAGS='-p=2 -mod=readonly', GOFIPS140='off', PYTHONDONTWRITEBYTECODE='1', NO_COLOR='1')
        for key in ('MAKEFLAGS', 'MAKEOVERRIDES', 'MAKEFILES', 'MFLAGS', 'NODE_OPTIONS', 'NODE_PATH', 'PYTHONPATH', 'PYTHONHOME'):
            env.pop(key, None)
        env['PYTHONNOUSERSITE'] = '1'
        env['OAPI_CODEGEN_VERSION'] = 'v2.5.1'
        env['OAPI_CODEGEN'] = str(prior.prior.GO) + ' run github.com/oapi-codegen/oapi-codegen/v2/cmd/oapi-codegen@v2.5.1'
        env['PATH'] = str(prior.NODE.parent) + ':' + str(prior.prior.GO.parent) + ':/usr/bin:/bin'
        receipt['selected_environment'] = {name: env[name] for name in ('GOTOOLCHAIN', 'GOWORK', 'GOMAXPROCS', 'GOFLAGS', 'GOFIPS140', 'PYTHONDONTWRITEBYTECODE', 'NO_COLOR', 'PYTHONNOUSERSITE', 'OAPI_CODEGEN_VERSION', 'OAPI_CODEGEN')}
        tasks = [
            ('codehealth-write', [str(prior.NODE), 'scripts/code-health-inventory.mjs', '--write'], 60),
            ('codehealth-check', [str(prior.NODE), 'scripts/code-health-inventory.mjs', '--check', '--verify-doc'], 60),
            ('operation-check', [str(prior.NODE), 'scripts/operation-task-inventory.mjs', '--check', '--verify-doc'], 60),
            ('json-governance', ['/usr/bin/python3.14', '-B', str(DIRECTORY / 'check_cached.py'), 'json', str(ROOT), str(output / 'json-actual.json')], 90),
            ('coupled-sql', ['/usr/bin/python3.14', '-B', str(DIRECTORY / 'check_cached.py'), 'sql', str(ROOT), str(output / 'sql-actual.json')], 90),
        ]
        for name, command, cap in tasks:
            remaining = deadline - time.monotonic(); assert remaining > 0, 'overall generator deadline'
            # Canonical inputs remain immutable; generated output changes are
            # expected and recorded through full source fingerprints separately.
            prior.after.ROOT = ROOT
            step = prior.after.run_step(command, command, env, output / (name + '.log'), guard, ownership, inputs, timeout=min(cap, remaining))
            receipt['steps'].append({'name': name, **step})
            if name == 'coupled-sql':
                outcome = step.get('outcome') or {}
                assert step['source_stable'] and step['final_guard_pass'] and outcome.get('drained') and outcome.get('leaderHeldUntilDrain')
                assert not outcome.get('reason') and not outcome.get('guardException') and not outcome.get('liveDescendantsAfterDrain')
                assert 'exception_category' not in step and outcome.get('exitCode') in (0, 1)
                receipt['coupled_sql'] = {'status': 'PASS' if outcome['exitCode'] == 0 else 'FAIL', 'actual_sha256': hashlib.sha256((output / 'sql-actual.json').read_bytes()).hexdigest(), 'diagnostic_sha256': hashlib.sha256((output / (name + '.log')).read_bytes()).hexdigest(), 'failure_accepted': False}
            else:
                assert prior.after.passed(step), 'generator or static check failed; originals retained'
            if name == 'go-version': assert (output / (name + '.log')).read_text().strip() == 'go version go1.27.2 linux/amd64'
            if name == 'node-version': assert (output / (name + '.log')).read_text().strip() == 'v26.11.1'
            ownership()
        receipt['changed_generated_paths'] = changed_paths()
        assert receipt['changed_generated_paths']==['docs/rancher-quality-phase0-code-health-inventory.md'],'expected one canonical doc change'
        assert len(receipt['steps']) == 5 and receipt.get('coupled_sql', {}).get('status') in ('PASS', 'FAIL')
        receipt['generation_pass'] = True
    except BaseException as error:
        receipt['failure_category'] = type(error).__name__
    finally:
        try:
            ownership(); receipt['inputs_after'] = inputs()
            receipt['source_after'] = prior.after.fences.fingerprint(ROOT)
            receipt['canonical_inputs_stable'] = receipt.get('inputs_before') == receipt['inputs_after']
            receipt['extension_modes_after'] = extension_modes()
            receipt['extension_modes_unchanged'] = verify_modes(receipt.get('extension_modes_before', []), receipt['extension_modes_after'])
            receipt['changed_generated_paths'] = changed_paths()
            shared_after = prior.shared_snapshot()
            (output / 'shared-after.json').write_text(json.dumps(shared_after) + '\n')
            receipt['shared_metadata_unchanged'] = shared_before == shared_after
        except BaseException as error:
            receipt['final_failure_category'] = type(error).__name__
        try:
            guard('runner-final'); receipt['runner_final_guard_pass'] = True
        except BaseException as error:
            receipt['final_guard_failure_category'] = type(error).__name__
        (output / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        for number, handler in previous.items(): signal.signal(number, handler)
    qualified = bool(receipt.get('generation_pass') and receipt.get('extension_modes_unchanged') and receipt.get('canonical_inputs_stable') and receipt.get('shared_metadata_unchanged') and receipt.get('runner_final_guard_pass') and not any(name in receipt for name in ('failure_category', 'final_failure_category', 'final_guard_failure_category')))
    print(json.dumps({'receipt': str(output / 'receipt.json'), 'canonical_document_pass': qualified, 'remaining_static_pass': qualified and receipt.get('coupled_sql', {}).get('status') == 'PASS', 'generated_diff_review_pending': True, 'coupled_sql': receipt.get('coupled_sql', {}).get('status', 'NOT_RUN')}))
    return 0 if qualified and receipt.get('coupled_sql', {}).get('status') == 'PASS' else 1


BINDING_SHA = '2086e34619671608a9e75d96c40aa15da0654ad9b832d603aa10b3d0a75455a3'
ALLOWED_SHA = '2038a0060bf68f61aab5c037e263dc6aa7bd83c32ff81c46374874e62e7534a8'
if __name__ == '__main__':
    raise SystemExit(main())
