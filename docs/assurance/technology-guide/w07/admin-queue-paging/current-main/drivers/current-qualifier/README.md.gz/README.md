Current W07 additive composition qualification

Run only after root allocates the sole native lane:

    python3 -B /tmp/w07-admin-queue-current-main-runner-c137c3cb/run_current.py /tmp/w07-admin-queue-current-main-c137c3cb-run1

The clean frozen source c137c3cb386f0d368888490669d529b412d1ea14 merges previously reviewed a01 with current main 7f6926af. The runner changes only SOURCE and the exact source-bindings digest from approved 6cc335. All 11 finite tasks, overall/per-task caps, default numeric guards, held ownership, exact 25-parent/48-terminal handler and four-parent/12-terminal SDK inventories, tool identity contracts and fail-closed static inventories remain identical. New current W14/worker source, 182 owners/897 SQL candidates, current JSON owners and measured ceilings are retained. The historical a01 binding manifest remains byte-identical in historical-source-bindings.json and is not current qualification authority. No old-a01 run, frontend repeat, generator, installation, database mutation or whole W07 completion claim. This successor is unlaunched; current capacity is RED.
