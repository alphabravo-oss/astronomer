"""Finite current-dependency qualification; frozen historical browser proof retained."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT=Path('/root/astronomer-all/astronomer-032-w07-current-main')
SOURCE='c137c3cb386f0d368888490669d529b412d1ea14'
DIRECTORY=Path(__file__).resolve().parent
ORIGINAL=Path('/tmp/w07-admin-queue-after-run-inventory-d2e33559/run_after.py')
assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()=='9ce55f8841ffaf140e675d34d782de87091f8da5540fdc0120d9a4e1dd9fbda5'
spec=importlib.util.spec_from_file_location('qualified_after',ORIGINAL)
qualified=importlib.util.module_from_spec(spec);spec.loader.exec_module(qualified)
base,prior,after=qualified.base,qualified.prior,qualified.after
GO,NODE=qualified.GO,qualified.NODE
INVENTORIES=json.loads((DIRECTORY/'inventories.json').read_text())


def check_bindings():
    assert hashlib.sha256((DIRECTORY/'source-bindings.json').read_bytes()).hexdigest()==BINDINGS_SHA
    for row in json.loads((DIRECTORY/'source-bindings.json').read_text()):
        path=Path(row['path']);assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
        if 'inode' in row:
            value=path.stat()
            assert (value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns)==(row['device'],row['inode'],row['size'],row['mtime_ns'])
    for name,digest in LOCAL_INPUTS.items():assert hashlib.sha256((DIRECTORY/name).read_bytes()).hexdigest()==digest


def main():
    assert len(sys.argv)==2
    output=Path(sys.argv[1]);os.umask(0o077)
    assert not output.resolve().is_relative_to(ROOT.resolve())
    output.mkdir(mode=0o700,parents=True,exist_ok=False)
    deadline=time.monotonic()+1500
    receipt={'source':SOURCE,'steps':[],'scope':'affected handler and SDK under composed current-main dependencies; full current JSON/SQL/boundary/complexity/generated inventories; historical unchanged browser proof retained without renewal; no installs, generator, live browser or database mutation','historical_runtime_receipt_sha256':'894a742b618b18052ed106f1f53d954283ac58575577a3b2b83dcf8fe8d07a32','historical_canonical_receipt_sha256':'6e4b807aea5914e22967b7a3f44aa3319a452ad511d9675827b0d931d8546ed6'}
    def guard(stage):
        check=subprocess.run(['bash','scripts/check-build-capacity.sh','--min-free-gib','20','--min-free-percent','20','--json'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=15)
        with (output/'capacity.jsonl').open('a') as stream:stream.write(json.dumps({'stage':stage,'time':time.time(),'exit':check.returncode,'stdout':check.stdout,'stderr':check.stderr})+'\n')
        prior.verify_guard(check.stdout,check.returncode)
    def ownership():
        check_bindings();prior.assert_go_identity();assert base.node_identity()==base.NODE_IDENTITY
        assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,timeout=10)==b''
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,timeout=10).decode().strip()==SOURCE
    previous={number:signal.signal(number,prior.interrupt) for number in (signal.SIGINT,signal.SIGTERM)}
    try:
        guard('initial');ownership()
        receipt['source_before']=after.fences.fingerprint(ROOT);receipt['go_before']=prior.go_identity();receipt['node_before']=base.node_identity()
        env=dict(os.environ,GOTOOLCHAIN='go1.27.2',GOWORK='off',GOMAXPROCS='4',GOFLAGS='-p=2 -mod=readonly',GOFIPS140='off',NO_COLOR='1')
        env['PATH']=str(NODE.parent)+':'+str(GO.parent)+':'+env['PATH']
        receipt['selected_environment']={key:env[key] for key in ('GOTOOLCHAIN','GOWORK','GOMAXPROCS','GOFLAGS','GOFIPS140','NO_COLOR')}
        tasks=[
            ('go-version',[str(GO),'version'],30),
            ('node-version',[str(NODE),'--version'],30),
            ('handler-race',[str(GO),'test','-race','-json','-count=1','-run','^('+'|'.join(INVENTORIES['handler_parents'])+')$','./internal/handler'],600),
            ('sdk-race',[str(GO),'test','-race','-json','-count=1','-run','^('+'|'.join(INVENTORIES['sdk_parents'])+')$','./pkg/astroclient'],300),
            ('vet',[str(GO),'vet','./internal/handler','./pkg/astroclient'],300),
            ('boundaries',[str(NODE),'scripts/check-dependency-boundaries.mjs'],60),
            ('complexity',[str(NODE),'scripts/check-complexity-budget.mjs'],60),
            ('code-health',[str(NODE),'scripts/code-health-inventory.mjs','--check','--verify-doc'],60),
            ('operation-inventory',[str(NODE),'scripts/operation-task-inventory.mjs','--check','--verify-doc'],60),
            ('json-governance',['/usr/bin/python3.14','-B',str(DIRECTORY/'check_cached.py'),'json',str(ROOT),str(output/'json-actual.json')],90),
            ('sql-governance',['/usr/bin/python3.14','-B',str(DIRECTORY/'check_cached.py'),'sql',str(ROOT),str(output/'sql-actual.json')],90),
        ]
        for name,command,cap in tasks:
            remaining=deadline-time.monotonic();assert remaining>0;after.ROOT=ROOT
            step=after.run_step(command,command,env,output/(name+'.log'),guard,ownership,lambda:after.fences.fingerprint(ROOT),timeout=min(cap,remaining))
            receipt['steps'].append({'name':name,**step});outcome=step.get('outcome') or {}
            assert step['source_stable'] and step['final_guard_pass'] and outcome.get('drained') and outcome.get('leaderHeldUntilDrain') and not outcome.get('reason') and not outcome.get('guardException')
            assert after.passed(step)
            log=output/(name+'.log')
            if name=='go-version':assert log.read_text().strip()=='go version go1.27.2 linux/amd64'
            elif name=='node-version':assert log.read_text().strip()=='v26.11.1'
            elif name=='handler-race':receipt['handler_events']=qualified.verify_go(log,base.PACKAGE,INVENTORIES['handler_cases'])
            elif name=='sdk-race':receipt['sdk_events']=qualified.verify_go(log,'github.com/alphabravocompany/astronomer-go/pkg/astroclient',INVENTORIES['sdk_cases'])
    except BaseException as error:receipt['failure_category']=type(error).__name__
    finally:
        try:
            ownership();receipt['source_after']=after.fences.fingerprint(ROOT);receipt['source_stable']=receipt.get('source_before')==receipt['source_after']
            receipt['go_after']=prior.go_identity();receipt['node_after']=base.node_identity()
            assert receipt.get('go_before')==receipt['go_after'] and receipt.get('node_before')==receipt['node_after']
        except BaseException as error:receipt['final_failure_category']=type(error).__name__
        try:guard('runner-final');receipt['runner_final_guard_pass']=True
        except BaseException as error:receipt['final_guard_failure_category']=type(error).__name__
        (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        for number,handler in previous.items():signal.signal(number,handler)
    passed=len(receipt['steps'])==11 and receipt.get('source_stable') and receipt.get('runner_final_guard_pass') and not any(key.endswith('failure_category') for key in receipt)
    print(json.dumps({'receipt':str(output/'receipt.json'),'current_dependency_qualification_pass':bool(passed)}))
    return 0 if passed else 1


BINDINGS_SHA='32bdc148a7d8b73a9cad6e5c1a74f7bc3a6de71c545ed61e1d04fc2f6efb4a56'
LOCAL_INPUTS={'inventories.json': 'a649d43ab36a6d9080e88a3f3bbb9d86e527d699a8462cd62c1026bc08f21754', 'check_cached.py': '3106b642857ef6789b46b1845e76ff10587a09a989e254a53b62bb861a64aaa0', 'test_controls.py': '7268e76c2187c09a6cfd06aece9109be0914d630739e22c3a0ec80d9c1d4f34a'}
if __name__=='__main__':raise SystemExit(main())
